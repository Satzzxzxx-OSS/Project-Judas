#include "PhysicsWorld.h"

#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <limits>
#include <map>
#include <optional>
#include <sstream>
#include <iomanip>
#include <cstring>
#include <tuple>
#include <utility>
#include <vector>

#include "Broadphase.h"
#include "CollisionShapes.h"
#include "ContactSolver.h"
#include "Contacts.h"
#include "Narrowphase.h"
#include "RadialTerrain.h"
#include "RigidBody.h"
#include "RigidMotion.h"
#include "ImpactSolver.h"

// Judas's own rigid-body physics — no middleware. Collision detection,
// contact generation, contact resolution, and integration are all owned
// here, built from RigidBody (state/integration), Contacts (narrowphase),
// and ContactSolver (impulse resolution). See docs/ARCHITECTURE.md,
// "Physics ownership" for the migration this replaces (Jolt Physics,
// used through the first Milestone 7-Final attempt) and why: no subsystem here — broadphase,
// narrowphase, contact resolution, the player's sweep query — assumes a
// world-space up axis; every one of them is expressed purely in terms of
// the shapes' and bodies' own positions/orientations. Judas already owned
// gravity, reference frames, and world coordinates before this milestone;
// this closes the remaining gap (collision/contact/rigid-body solving)
// that used to belong to Jolt.
namespace {

using Clock = std::chrono::steady_clock;
double MillisecondsBetween(Clock::time_point a, Clock::time_point b) {
    return std::chrono::duration<double, std::milli>(b - a).count();
}

// Milestone 32: how far a proxy's fat bound extends past its tight bound.
// A body that moves less than this within its fat box costs the tree
// nothing; one that escapes is reinserted. Static bodies use the same
// margin (only kinematically-driven static bodies such as doors move).
constexpr float kBroadphaseMargin = 0.1f;
// Tolerance added to the player sweep's query box.
constexpr float kSweepQueryEpsilon = 1.0e-3f;
// Warm starting: a new contact inherits last step's converged impulses from
// the same body pair/primitive pair when its anchor (in body A's frame) is
// within this distance of a cached one and the normals agree.
constexpr float kWarmStartAnchorDistance = 0.05f;
constexpr float kWarmStartNormalDot = 0.9f;

struct ContactKey {
    unsigned int slotA = 0, slotB = 0;
    unsigned int generationA = 0, generationB = 0;
    int partA = 0, partB = 0;
    bool operator<(const ContactKey& o) const {
        return std::tie(slotA, slotB, partA, partB) < std::tie(o.slotA, o.slotB, o.partA, o.partB);
    }
    bool SameBodies(const ContactKey& o) const {
        return slotA == o.slotA && slotB == o.slotB && partA == o.partA && partB == o.partB &&
               generationA == o.generationA && generationB == o.generationB;
    }
};
struct CachedContact {
    ContactKey key;
    glm::dvec3 localAnchorA{0.0};
    glm::vec3 normal{0.0f};
    float normalImpulse = 0.0f;
    glm::vec3 tangentImpulse{0.0f};
};

std::vector<BodyBox> BoxesAt(const Shape& shape, const glm::vec3& position,
                              const glm::quat& orientation) {
    std::vector<BodyBox> boxes;
    if (shape.type == ShapeType::Box) {
        boxes.push_back({position, orientation, shape.halfExtents});
    } else if (shape.type == ShapeType::CompoundBoxes) {
        boxes.reserve(shape.boxes.size());
        for (const CompoundBox& child : shape.boxes) {
            boxes.push_back({position + orientation * child.localCenter,
                             orientation, child.halfExtents});
        }
    }
    return boxes;
}

glm::mat3 CompoundInverseInertia(float mass, const std::vector<CompoundBox>& boxes) {
    float totalVolume = 0.0f;
    for (const CompoundBox& box : boxes) {
        totalVolume += 8.0f * box.halfExtents.x * box.halfExtents.y * box.halfExtents.z;
    }
    if (mass <= 0.0f || totalVolume <= 0.0f) return glm::mat3(0.0f);

    // Uniform density, with the parallel-axis theorem for each child. The
    // resulting full tensor includes products of inertia when the geometry
    // is asymmetric; RigidBody rotates it to world space as usual.
    glm::mat3 inertia(0.0f);
    for (const CompoundBox& box : boxes) {
        const float childMass = mass *
            (8.0f * box.halfExtents.x * box.halfExtents.y * box.halfExtents.z / totalVolume);
        const glm::vec3 h = box.halfExtents;
        inertia[0][0] += childMass * (h.y * h.y + h.z * h.z) / 3.0f;
        inertia[1][1] += childMass * (h.x * h.x + h.z * h.z) / 3.0f;
        inertia[2][2] += childMass * (h.x * h.x + h.y * h.y) / 3.0f;
        const glm::vec3& r = box.localCenter;
        inertia += childMass * (glm::dot(r, r) * glm::mat3(1.0f) - glm::outerProduct(r, r));
    }
    return glm::determinant(inertia) > 1.0e-12f ? glm::inverse(inertia) : glm::mat3(0.0f);
}

}  // namespace

// Distance (and separating normal/owning body index) from the player's
// capsule, placed at a given segment, to the closest world body — used by
// SweepPlayerShape's substep march. `bodyIndex == -1` means no body was
// found closer than `distance`'s initial +infinity (never happens once any
// world geometry exists, but keeps the result total).
struct ClosestBodyResult {
    float distance = std::numeric_limits<float>::max();
    glm::vec3 normal{0.0f};
    int bodyIndex = -1;
};

struct PhysicsWorld::Impl {
    struct PoseBound {
        glm::vec3 position{0};
        glm::quat orientation{1,0,0,0};
        Aabb bound;
        bool valid = false;
    };
    struct Body {
        RigidBody rigidBody;
        // Previous fixed-step pose for player movement sweeps against
        // dynamic targets; initialized together with the current pose and
        // refreshed immediately before every physics integration.
        glm::vec3 previousPosition{0.0f};
        RigidMotion motion;
        glm::quat previousOrientation{1.0f, 0.0f, 0.0f, 0.0f};
        Shape shape;
        // Shape is immutable for this slot generation. AddBody replaces the
        // entire cache on slot reuse, including all compound child dimensions.
        float boundingRadius = 0;
        std::optional<ContactPreparedOrientation> orientationCache;
        std::optional<PreparedShapeBounds> boundPreparation;
        bool boundPreparationValid = false;
        PoseBound currentBound, previousBound;
        float friction = 0.5f;
        float restitution = 0.0f;
        bool isDynamic = false;
        bool alive = false;
        // Milestone 29: a slot is reused after DestroyBody; the generation
        // in the handle's upper bits makes a handle from a previous
        // occupant of the same slot invalid instead of aliasing the new one.
        unsigned int generation = 0;
        // Milestone 32: this body's leaf in the broadphase tree.
        int proxy = DynamicAabbTree::kNull;
    };

    static constexpr unsigned int kSlotBits = 20;
    static constexpr unsigned int kSlotMask = (1u << kSlotBits) - 1u;

    std::vector<Body> bodies;
    // Slots of destroyed bodies awaiting reuse, and the sorted slots of
    // every live body — the loops below iterate this so a world whose
    // entities were unloaded pays for the bodies that exist, not for the
    // slots they once occupied.
    std::vector<unsigned int> freeSlots;
    std::vector<unsigned int> aliveSlots;
    std::vector<PhysicsWorld::DebugContact> lastStepContacts;

    // Milestone 32: broadphase, the per-step candidate list, the solver
    // (reused so its storage is not reallocated every step) and statistics.
    DynamicAabbTree tree;
    std::vector<std::pair<unsigned int, unsigned int>> candidatePairs;
    mutable std::vector<unsigned int> queryScratch;
    ContactSolver solver;
    ImpactSolver impactSolver;
    struct StartContact {
        unsigned a,b;
        std::size_t constraint;
        float friction, warmNormal;
        glm::vec3 warmTangent;
        bool newImpact;
    };
    std::vector<StartContact> startContacts;
    std::vector<std::array<unsigned,4>> separatedPairs;
    std::vector<std::array<unsigned,4>> supportPairs;
    struct ScheduledImpact { std::array<unsigned,4> key; double time; };
    std::vector<ScheduledImpact> scheduledImpacts;
    std::vector<unsigned> impactCounts;
    std::vector<unsigned char> impactCapped;
    double stepDuration = 0;

    RigidBody PoseAt(unsigned slot, double time) const {
        const Body& b=bodies[slot];
        RigidBody pose=b.rigidBody;
        if (b.isDynamic && !b.motion.Segments().empty()) {
            const auto sampled=b.motion.Evaluate(time);
            pose.position=sampled.position; pose.orientation=sampled.orientation;
        }
        return pose;
    }
    static double NormalSpeed(const Contact& c,const RigidBody& a,const RigidBody& b) {
        const glm::dvec3 ra=c.hasLocalAnchors ? (c.anchorAInWorldFrame ? c.localAnchorA : ContactRotation(a.orientation)*c.localAnchorA) :
            glm::dvec3(c.point)-glm::dvec3(a.position);
        const glm::dvec3 rb=c.hasLocalAnchors ? (c.anchorBInWorldFrame ? c.localAnchorB : ContactRotation(b.orientation)*c.localAnchorB) :
            glm::dvec3(c.point)-glm::dvec3(b.position);
        return glm::dot(glm::dvec3(c.normal),glm::dvec3(a.linearVelocity-b.linearVelocity)+
            glm::cross(glm::dvec3(a.angularVelocity),ra)-glm::cross(glm::dvec3(b.angularVelocity),rb));
    }
    ContactManifold PairAt(unsigned a,unsigned b,int pa,int pb,double time,float margin) const {
        const auto aa=PoseAt(a,time),bb=PoseAt(b,time);
        const ContactPreparedOrientation oa(aa.orientation),ob(bb.orientation);
        return ComputeContacts(PrimitiveAt(bodies[a].shape,aa,pa,&oa),
            PrimitiveAt(bodies[b].shape,bb,pb,&ob),margin,&oa,&ob);
    }
    // Lower bound on a fixed separating-plane gap along the anchored drift.
    // For q(t)=normalize(q0+t*Omega*q0/2), instantaneous angular speed is
    // |omega|/(1+(|omega|t/2)^2). Every rotated vertex has |r''|<=|omega|^2|r_perp|.
    // Evaluate ALL support vertices, including those not currently extremal.
    double PlaneDrift(unsigned a,unsigned b,int pa,int pb,double time,const glm::dvec3& n) const {
        struct Vertex {glm::dvec3 r,velocity;double curvature;};
        struct Support {std::array<Vertex,8> vertices;int count=0;double radius=0;};
        auto support=[&](unsigned slot,int part) {
            Support result;const auto& body=bodies[slot];const auto pose=PoseAt(slot,time);
            const auto child=PrimitiveAt(body.shape,pose,part);
            if(child.shape.type!=ShapeType::Box && child.shape.type!=ShapeType::Sphere) return result;
            const auto rotation=ContactRotation(pose.orientation);
            const glm::dvec3 omega(body.rigidBody.IsStatic()?glm::vec3(0):body.rigidBody.angularVelocity);
            const double w2=glm::dot(omega,omega);
            const double elapsed=body.isDynamic && !body.motion.Segments().empty() ? time-body.motion.Segments().back().begin : 0;
            const glm::dvec3 instantaneous=omega/(1+.25*w2*elapsed*elapsed);
            auto vertex=[&](glm::dvec3 local) {
                const glm::dvec3 r=rotation*local;
                const glm::dvec3 perpendicular=w2>0 ? r-omega*(glm::dot(omega,r)/w2) : glm::dvec3(0);
                result.vertices[result.count++]={r,glm::dvec3(body.rigidBody.IsStatic()?glm::vec3(0):body.rigidBody.linearVelocity)+glm::cross(instantaneous,r),
                                                  w2*glm::length(perpendicular)};
            };
            if(child.shape.type==ShapeType::Sphere) {vertex(glm::dvec3(child.parentLocalCenter));result.radius=child.shape.radius;}
            else for(int k=0;k<8;++k) vertex(glm::dvec3(child.parentLocalCenter)+glm::dvec3(child.shape.halfExtents)*
                glm::dvec3(k&1?1:-1,k&2?1:-1,k&4?1:-1));
            return result;
        };
        const auto sa=support(a,pa),sb=support(b,pb);
        if(!sa.count || !sb.count) return 0;
        const glm::dvec3 delta=glm::dvec3(PoseAt(a,time).position)-glm::dvec3(PoseAt(b,time).position);
        double advance=std::numeric_limits<double>::infinity();
        for(int i=0;i<sa.count;++i) for(int j=0;j<sb.count;++j) {
            const auto& va=sa.vertices[i];const auto& vb=sb.vertices[j];
            const double gap=glm::dot(n,delta+va.r-vb.r)-sa.radius-sb.radius;
            if(!(gap>0)) return 0; // This sampled normal cannot certify a separating plane.
            const double rate=glm::dot(n,va.velocity-vb.velocity),curvature=va.curvature+vb.curvature;
            double root=std::numeric_limits<double>::infinity();
            if(curvature>0) {
                const double discriminant=std::sqrt(rate*rate+2*curvature*gap);
                root=rate<0 ? 2*gap/(discriminant-rate) : (rate+discriminant)/curvature;
            } else if(rate<0) root=-gap/rate;
            advance=std::min(advance,root);
        }
        return advance;
    }

    // Conservative advancement along a separating plane. Translation projected
    // onto that plane plus |omega|*radius bounds its possible closing speed.
    // Anchored quaternion interpolation turns no faster than |omega|.
    double ImpactTime(unsigned a,unsigned b,int pa,int pb,double start,double finish) {
        ++stats.impactQueries;
        const auto& ba=bodies[a]; const auto& bb=bodies[b];
        const glm::dvec3 relative=glm::dvec3(ba.rigidBody.IsStatic()?glm::vec3(0):ba.rigidBody.linearVelocity)-glm::dvec3(bb.rigidBody.IsStatic()?glm::vec3(0):bb.rigidBody.linearVelocity);
        const double angular=(ba.rigidBody.IsStatic()?0:glm::length(glm::dvec3(ba.rigidBody.angularVelocity))*ba.boundingRadius)+
                             (bb.rigidBody.IsStatic()?0:glm::length(glm::dvec3(bb.rigidBody.angularVelocity))*bb.boundingRadius);
        const double speed=glm::length(relative)+angular;
        if (!(speed>0)) return finish+1;
        double time=start, previous=start;
        bool uncertifiedAdvance=false;
        for (int iteration=0;iteration<64;++iteration) {
            ++stats.impactSearchIterations;stats.impactPeakIterations=std::max(stats.impactPeakIterations,std::size_t(iteration+1));
            const float reach=std::nextafter(static_cast<float>(speed*(finish-time)),
                                             std::numeric_limits<float>::infinity());
            // Margin manifolds contain proximity features, not necessarily the
            // zero-margin contact set. Contact truth must use the latter.
            const auto actual=PairAt(a,b,pa,pb,time,0);
            if(actual.count) {
                if(time==start) return finish+1;
                double lo=previous,hi=time;
                for(int k=0;k<32;++k) {
                    const double mid=(lo+hi)*.5;
                    if(PairAt(a,b,pa,pb,mid,0).count) hi=mid;else lo=mid;
                }
                return hi;
            }
            const auto manifold=PairAt(a,b,pa,pb,time,reach);
            if (!manifold.count) return finish+1;
            const Contact* nearest=&manifold.points[0];
            for (int k=1;k<manifold.count;++k)
                if (manifold.points[k].signedSeparation<nearest->signedSeparation) nearest=&manifold.points[k];
            const double gap=nearest->hasLocalAnchors ? nearest->signedSeparation : -double(nearest->penetration);
            if(gap<=0) {
                // Some specialized geometry (notably terrain) excludes exact
                // equality at zero margin while a proximity query includes it.
                // The latter is not a certified separating plane or an impact.
                // Let bounded actual-contact sampling establish contact truth.
                ++stats.impactUncertifiedAdvances;
                uncertifiedAdvance=true;
                break;
            }
            const double closing=-glm::dot(relative,nearest->hasLocalAnchors ? nearest->preciseNormal : glm::dvec3(nearest->normal))+angular;
            if (!(closing>0)) return finish+1;
            double increment=gap/closing;
            if(angular>0) increment=std::max(increment,PlaneDrift(a,b,pa,pb,time,nearest->hasLocalAnchors ? nearest->preciseNormal : glm::dvec3(nearest->normal)));
            // Progress in represented time only. A large coordinate orthogonal
            // to motion must not enlarge the step and skip a thin obstacle.
            increment=std::max(increment,std::nextafter(time,finish)-time);
            previous=time;
            time=std::min(finish,time+increment);
            if (time<=previous) return finish+1;
        }
        if(!uncertifiedAdvance) ++stats.impactSearchLimit;
        ++stats.impactSamplingFallbacks;
        // Rotating grazing features can keep a fixed separating-plane bound
        // arbitrarily short. Finish this PAIR query with a bounded temporal
        // sampling approximation, never by applying an impulse across a gap.
        // Intersections shorter than the reported sampling interval can be
        // missed; this is deliberately not a complete continuous-CCD proof.
        auto firstContact=[&](double lo,double hi) {
            for(int k=0;k<32;++k) {
                const double mid=(lo+hi)*.5;
                if(PairAt(a,b,pa,pb,mid,0).count) hi=mid;else lo=mid;
            }
            return hi;
        };
        ++stats.impactSamplingTests;
        if(PairAt(a,b,pa,pb,time,0).count) return firstContact(previous,time);
        const double remaining=finish-time;
        if(!(remaining>0)) return finish+1;
        auto primitiveFeature=[&](unsigned slot,int part) {
            const Shape& shape=bodies[slot].shape;
            if(shape.type==ShapeType::Sphere) return double(shape.radius);
            const glm::vec3 half=shape.type==ShapeType::CompoundBoxes
                ? shape.boxes[std::size_t(part)].halfExtents : shape.halfExtents;
            if(shape.type==ShapeType::Box || shape.type==ShapeType::CompoundBoxes)
                return double(std::min({half.x,half.y,half.z}));
            // Terrain uses the other, finite rigid primitive's feature size.
            return std::numeric_limits<double>::infinity();
        };
        const double feature=std::min(primitiveFeature(a,pa),primitiveFeature(b,pb));
        if(!(feature>0)) throw std::runtime_error("invalid primitive feature in impact sampling");
        const double angularSpeed=(ba.rigidBody.IsStatic()?0:glm::length(glm::dvec3(ba.rigidBody.angularVelocity)))+
                                  (bb.rigidBody.IsStatic()?0:glm::length(glm::dvec3(bb.rigidBody.angularVelocity)));
        const double requested=std::max({16.0,std::ceil(16.0*speed*remaining/feature),
                                              std::ceil(256.0*angularSpeed*remaining)});
        constexpr unsigned kMaxSamples=65536;
        if(requested>double(kMaxSamples)) ++stats.impactSamplingResolutionCaps;
        const unsigned samples=static_cast<unsigned>(std::min(double(kMaxSamples),requested));
        const double interval=remaining/double(samples);
        stats.impactSamplingMaxInterval=std::max(stats.impactSamplingMaxInterval,interval);
        double lo=time;
        for(unsigned sample=1;sample<=samples;++sample) {
            const double hi=sample==samples ? finish : time+remaining*(double(sample)/double(samples));
            ++stats.impactSamplingTests;
            if(PairAt(a,b,pa,pb,hi,0).count) return firstContact(lo,hi);
            lo=hi;
        }
        return finish+1;
    }

    void ResolveInitialImpacts(float dt) {
        if (std::none_of(startContacts.begin(),startContacts.end(),[](const auto& c){return c.newImpact;})) return;
        std::vector<Contact> geometry;
        geometry.reserve(solver.Constraints().size());
        for(const auto& c:solver.Constraints()) {
            Contact g;g.hit=true;g.point=c.point;g.normal=c.normal;g.preciseNormal=c.preciseNormal;
            g.penetration=c.penetration;g.signedSeparation=c.signedSeparation;
            g.localAnchorA=c.localAnchorA;g.localAnchorB=c.localAnchorB;g.hasLocalAnchors=c.hasLocalAnchors;
            g.anchorAInWorldFrame=c.anchorAInWorldFrame;g.anchorBInWorldFrame=c.anchorBInWorldFrame;
            geometry.push_back(g);
        }
        std::vector<unsigned> parent(bodies.size());
        for (unsigned i=0;i<parent.size();++i) parent[i]=i;
        auto root=[&](unsigned i){while(parent[i]!=i) {parent[i]=parent[parent[i]];i=parent[i];}return i;};
        for (const auto& c:startContacts) if (!bodies[c.a].rigidBody.IsStatic() && !bodies[c.b].rigidBody.IsStatic())
            parent[root(c.b)]=root(c.a);
        std::vector<std::pair<unsigned,std::size_t>> order;
        for (std::size_t i=0;i<startContacts.size();++i) {
            const auto& c=startContacts[i];
            order.emplace_back(root(bodies[c.a].rigidBody.IsStatic()?c.b:c.a),i);
        }
        std::sort(order.begin(),order.end());
        for (std::size_t begin=0;begin<order.size();) {
            std::size_t end=begin+1; bool impact=startContacts[order[begin].second].newImpact;
            while(end<order.size() && order[end].first==order[begin].first) {
                impact=impact||startContacts[order[end].second].newImpact;++end;
            }
            if (impact) {
                std::vector<ImpactContact> rows;
                for (auto k=begin;k<end;++k) {
                    auto& c=startContacts[order[k].second];
                    const bool persistent=c.warmNormal>0;
                    c.warmNormal=0;c.warmTangent=glm::vec3(0);
                    if (geometry[c.constraint].signedSeparation>0) continue;
                    auto& a=bodies[c.a];auto& b=bodies[c.b];
                    rows.push_back({&a.rigidBody,&b.rigidBody,geometry[c.constraint],c.friction,
                                    std::max(a.restitution,b.restitution),persistent});
                }
                const auto result=impactSolver.Solve(rows,dt);
                if(!result.energyBudgetSatisfied) throw std::runtime_error("inelastic impact energy guard failed");
                if(result.effectiveRestitution==0) for(auto k=begin;k<end;++k) startContacts[order[k].second].newImpact=false;
                ++stats.impactEvents; stats.impactSafetyFallback+=result.safetyFallback;
            }
            begin=end;
        }
        // Only the rare time-zero impact path needs rebuilt warm-start inputs.
        // Persistent contact solver arithmetic and APIs remain unchanged.
        solver.Clear();
        for(const auto& c:startContacts) {
            auto& a=bodies[c.a];auto& b=bodies[c.b];
            const auto& oa=Orientation(a);const auto& ob=Orientation(b);
            solver.AddContact(a.rigidBody,b.rigidBody,geometry[c.constraint],c.friction,0,
                c.warmNormal,c.warmTangent,&oa.rotation,&ob.rotation);
        }
    }

    void AdvanceImpacts(float dt) {
        stepDuration=dt;
        impactCounts.assign(bodies.size(),0); impactCapped.assign(bodies.size(),0);
        for (const auto slot:aliveSlots) if (bodies[slot].isDynamic)
            bodies[slot].motion.Begin(MakeHandle(slot).id,bodies[slot].rigidBody,dt);
        // Initial touching impacts can launch a previously stationary body.
        // Refresh those trajectories before searching for a separated event.
        if(stats.impactEvents) {
            for(auto slot:aliveSlots) if(bodies[slot].isDynamic) CoverStepReach(bodies[slot],dt);
            GenerateCandidatePairs(); separatedPairs.clear();
            for(const auto& pair:candidatePairs)
                for(int pa=0;pa<PrimitiveCount(bodies[pair.first].shape);++pa)
                    for(int pb=0;pb<PrimitiveCount(bodies[pair.second].shape);++pb)
                        separatedPairs.push_back({pair.first,pair.second,unsigned(pa),unsigned(pb)});
        }
        double now=0;
        scheduledImpacts.clear();
        std::map<std::array<unsigned,4>,std::size_t> scheduledIndex;
        auto schedule=[&](const std::array<unsigned,4>& key) {
            const double time=std::binary_search(supportPairs.begin(),supportPairs.end(),key) ? double(dt)+1 :
                ImpactTime(key[0],key[1],int(key[2]),int(key[3]),now,dt);
            const auto found=scheduledIndex.find(key);
            if(found!=scheduledIndex.end()) scheduledImpacts[found->second].time=time;
            else {scheduledIndex.emplace(key,scheduledImpacts.size());scheduledImpacts.push_back({key,time});}
        };
        for(const auto& key:separatedPairs) schedule(key);
        for (;;) {
            double earliest=double(dt)+1; unsigned seedA=0,seedB=0;
            std::array<unsigned,4> selected{};
            for (const auto& event:scheduledImpacts) {
                if(event.time<earliest || (event.time==earliest && event.key<selected)) {
                    earliest=event.time;selected=event.key;seedA=event.key[0];seedB=event.key[1];
                }
            }
            if (earliest>dt) break;
            now=earliest;
            std::vector<unsigned> island;
            std::vector<unsigned char> included(bodies.size(),0);
            auto include=[&](unsigned slot){if(!included[slot] && !bodies[slot].rigidBody.IsStatic()) {
                included[slot]=1;island.push_back(slot);}};
            include(seedA);include(seedB);
            std::vector<std::pair<unsigned,unsigned>> touching;
            for (std::size_t next=0;next<island.size();++next) {
                const unsigned a=island[next]; const auto pose=PoseAt(a,now);
                const auto candidates=QuerySlots(ShapeAabb(bodies[a].shape,pose.position,pose.orientation));
                for (unsigned b:candidates) {
                    if (a==b) continue;
                    const auto pair=std::minmax(a,b);
                    if (std::find(touching.begin(),touching.end(),std::pair<unsigned,unsigned>(pair))!=touching.end()) continue;
                    bool hit=false;
                    for(int pa=0;pa<PrimitiveCount(bodies[a].shape);++pa)
                        for(int pb=0;pb<PrimitiveCount(bodies[b].shape);++pb)
                            hit=hit||PairAt(a,b,pa,pb,now,0).count>0;
                    if(hit) {touching.emplace_back(pair);include(b);}
                }
            }
            // A supported body's incoming impact is mechanically coupled even
            // when a cached support point currently has a small positive gap.
            // This only chooses restitution zero: separated support geometry
            // is never inserted into the actual-contact impulse rows below.
            const bool supportedIsland=std::any_of(supportPairs.begin(),supportPairs.end(),
                [&](const auto& pair){return included[pair[0]] || included[pair[1]];});
            bool capture=supportedIsland;
            std::vector<std::pair<glm::vec3,glm::vec3>> oldVelocities;
            oldVelocities.reserve(island.size());
            for(unsigned slot:island) {
                auto& body=bodies[slot];const auto pose=PoseAt(slot,now);
                oldVelocities.emplace_back(body.rigidBody.linearVelocity,body.rigidBody.angularVelocity);
                body.rigidBody.position=pose.position;body.rigidBody.orientation=pose.orientation;
                if (++impactCounts[slot]>16) {
                    if(!impactCapped[slot]) {impactCapped[slot]=1;++stats.impactEventCapFallback;}
                    capture=true;
                }
            }
            std::vector<ImpactContact> rows;
            std::vector<std::array<unsigned,4>> eventPairs;
            for (const auto& pair:touching) {
                auto& a=bodies[pair.first];auto& b=bodies[pair.second];
                for(int pa=0;pa<PrimitiveCount(a.shape);++pa)
                    for(int pb=0;pb<PrimitiveCount(b.shape);++pb) {
                        const auto m=PairAt(pair.first,pair.second,pa,pb,now,0);
                        if(m.count) eventPairs.push_back({pair.first,pair.second,unsigned(pa),unsigned(pb)});
                        for(int k=0;k<m.count;++k) {
                            rows.push_back({&a.rigidBody,&b.rigidBody,m.points[k],
                                std::sqrt(std::max(0.f,a.friction)*std::max(0.f,b.friction)),
                                std::max(a.restitution,b.restitution),false});
                            lastStepContacts.push_back({m.points[k].point,m.points[k].normal,m.points[k].penetration});
                        }
                    }
            }
            if(rows.empty()) throw std::runtime_error("impact bracket lost contact geometry");
            const auto result=impactSolver.Solve(rows,dt,capture);
            if(!result.energyBudgetSatisfied) throw std::runtime_error("inelastic impact energy guard failed");
            if(result.effectiveRestitution==0) {
                supportPairs.insert(supportPairs.end(),eventPairs.begin(),eventPairs.end());
                std::sort(supportPairs.begin(),supportPairs.end());supportPairs.erase(std::unique(supportPairs.begin(),supportPairs.end()),supportPairs.end());
            }
            ++stats.impactEvents;stats.impactSafetyFallback+=result.safetyFallback;
            contactCache.erase(std::remove_if(contactCache.begin(),contactCache.end(),
                [&](const CachedContact& c){return included[c.key.slotA] || included[c.key.slotB];}),contactCache.end());
            std::vector<unsigned> changed;
            for(std::size_t i=0;i<island.size();++i) {
                const auto slot=island[i];auto& b=bodies[slot];
                if(SamePosition(oldVelocities[i].first,b.rigidBody.linearVelocity) &&
                   SamePosition(oldVelocities[i].second,b.rigidBody.angularVelocity)) continue;
                changed.push_back(slot);
                b.motion.ChangeVelocity(b.rigidBody,now);
                CoverStepReach(b,static_cast<float>(dt-now));
                supportPairs.erase(std::remove_if(supportPairs.begin(),supportPairs.end(),[&](const auto& pair) {
                    return (pair[0]==slot || pair[1]==slot) &&
                        std::find(eventPairs.begin(),eventPairs.end(),pair)==eventPairs.end();
                }),supportPairs.end());
            }
            // Cached event times depend only on the two anchored trajectories.
            // Recompute incident queries after an actual velocity change; retain
            // every unaffected event (including disjoint simultaneous events).
            std::vector<std::array<unsigned,4>> dirty;
            dirty.push_back(selected); // retire the event even if its impulse is zero
            for(const auto& event:scheduledImpacts)
                if(std::find(changed.begin(),changed.end(),event.key[0])!=changed.end() ||
                   std::find(changed.begin(),changed.end(),event.key[1])!=changed.end()) dirty.push_back(event.key);
            for(unsigned slot:changed) {
                const auto candidates=QuerySlots(tree.FatAabb(bodies[slot].proxy));
                for(unsigned other:candidates) if(other!=slot) {
                    const auto a=std::min(slot,other),b=std::max(slot,other);
                    for(int pa=0;pa<PrimitiveCount(bodies[a].shape);++pa)
                        for(int pb=0;pb<PrimitiveCount(bodies[b].shape);++pb)
                            dirty.push_back({a,b,unsigned(pa),unsigned(pb)});
                }
            }
            std::sort(dirty.begin(),dirty.end());dirty.erase(std::unique(dirty.begin(),dirty.end()),dirty.end());
            for(const auto& key:dirty) schedule(key);
            if(now>=dt) break;
        }
        for(const auto slot:aliveSlots) if(bodies[slot].isDynamic) {
            auto& body=bodies[slot];const auto pose=body.motion.Evaluate(dt);
            stats.motionSegments+=body.motion.Segments().size();stats.motionStorageBytes+=body.motion.StorageBytes();
            body.rigidBody.position=pose.position;body.rigidBody.orientation=pose.orientation;
        }
    }

    // Milestone 32 warm-start state: last step's converged impulses, sorted
    // by key, and the keys/anchors of this step's constraints in solver order.
    std::vector<CachedContact> contactCache;
    std::vector<CachedContact> pendingCache;
    std::vector<char> cacheUsed;
    PhysicsWorld::StepStats stats;
    std::size_t reinsertionsSinceStep = 0;
    struct CacheCounters {
        std::size_t orientationHits=0, orientationRebuilds=0;
        std::size_t boundHits=0, boundRebuilds=0, shapeRebuilds=0, allocations=0, allocatedBytes=0;
    } cacheCounters;

    static bool SameFloat(float a, float b) {
        return std::memcmp(&a,&b,sizeof(float))==0;
    }
    static bool SamePosition(const glm::vec3& a,const glm::vec3& b) {
        return SameFloat(a.x,b.x) && SameFloat(a.y,b.y) && SameFloat(a.z,b.z);
    }
    static bool SameRotation(const glm::quat& a,const glm::quat& b) {
        return SameFloat(a.w,b.w) && SameFloat(a.x,b.x) && SameFloat(a.y,b.y) && SameFloat(a.z,b.z);
    }
    static bool Matches(const PoseBound& bound,const glm::vec3& p,const glm::quat& q) {
        return bound.valid && SamePosition(bound.position,p) && SameRotation(bound.orientation,q);
    }
    const ContactPreparedOrientation& Orientation(Body& body) {
        if (body.orientationCache && body.orientationCache->Matches(body.rigidBody.orientation)) {
            ++cacheCounters.orientationHits;
        } else {
            body.orientationCache.emplace(body.rigidBody.orientation);
            body.boundPreparationValid = false;
            ++cacheCounters.orientationRebuilds;
        }
        return *body.orientationCache;
    }
    const Aabb& CurrentBound(Body& body) {
        const auto& p=body.rigidBody.position;
        const auto& q=body.rigidBody.orientation;
        if (Matches(body.currentBound,p,q)) {
            ++cacheCounters.boundHits;
            return body.currentBound.bound;
        }
        const auto& orientation=Orientation(body);
        if (!body.boundPreparationValid) {
            if (!body.boundPreparation) body.boundPreparation.emplace();
            const auto capacity=body.boundPreparation->children.capacity();
            PrepareShapeBounds(body.shape,orientation,*body.boundPreparation);
            if (body.boundPreparation->children.capacity()!=capacity) {
                ++cacheCounters.allocations;
                cacheCounters.allocatedBytes+=body.boundPreparation->children.capacity()*sizeof(PreparedBoxBound);
            }
            body.boundPreparationValid=true;
        }
        body.currentBound={p,q,ShapeAabb(*body.boundPreparation,p),true};
        ++cacheCounters.boundRebuilds;
        return body.currentBound.bound;
    }
    const Aabb& PreviousBound(Body& body) {
        const auto& p=body.previousPosition;
        const auto& q=body.previousOrientation;
        if (Matches(body.previousBound,p,q)) {
            ++cacheCounters.boundHits;
        } else if (Matches(body.currentBound,p,q)) {
            body.previousBound=body.currentBound;
            ++cacheCounters.boundHits;
        } else {
            // Normally captured before integration. This independent fallback
            // preserves the old pose if a caller introduces another transition.
            body.previousBound={p,q,ShapeAabb(body.shape,p,q),true};
            ++cacheCounters.boundRebuilds;
        }
        return body.previousBound.bound;
    }
    std::size_t CacheBytes() const {
        std::size_t bytes=bodies.capacity()*(sizeof(float)+sizeof(std::optional<ContactPreparedOrientation>)+
            sizeof(std::optional<PreparedShapeBounds>)+sizeof(bool)+2*sizeof(PoseBound));
        for (const Body& body:bodies) if (body.boundPreparation)
            bytes+=body.boundPreparation->children.capacity()*sizeof(PreparedBoxBound);
        return bytes+solver.FrameStorageBytes();
    }

    // The tight broadphase bound a body must stay inside. For a dynamic
    // body it covers both the previous and the current fixed-step pose —
    // player sweeps interpolate between the two — and, if the body turned
    // during the step, the orientation-independent bounding sphere at both
    // positions (an interpolated orientation can poke outside both
    // endpoint boxes; it can never leave the swept sphere).
    Aabb TightBound(Body& body) {
        const Aabb current = CurrentBound(body);
        if (!body.isDynamic) { body.previousBound=body.currentBound; return current; }
        Aabb bound = current.Union(PreviousBound(body));
        const float turn = std::abs(glm::dot(body.previousOrientation, body.rigidBody.orientation));
        if (turn < 1.0f - 1.0e-7f) {
            const float r = body.boundingRadius;
            bound = bound.Union(Aabb{body.previousPosition - glm::vec3(r), body.previousPosition + glm::vec3(r)});
            bound = bound.Union(Aabb{body.rigidBody.position - glm::vec3(r), body.rigidBody.position + glm::vec3(r)});
        }
        if (body.motion.Segments().size()>1) for(const auto& segment:body.motion.Segments()) {
            const float r=body.boundingRadius;
            bound=bound.Union(Aabb{glm::min(segment.position,segment.endPosition)-glm::vec3(r),
                                  glm::max(segment.position,segment.endPosition)+glm::vec3(r)});
        }
        return bound;
    }

    // Milestone 32: how far this body's surface can move within the current
    // step at its post-force velocities — the most any of its contacts can
    // close before the next detection.
    float StepReach(const Body& body, float fixedDeltaTime) const {
        return (glm::length(body.rigidBody.linearVelocity) +
                glm::length(body.rigidBody.angularVelocity) * body.boundingRadius) *
               fixedDeltaTime;
    }

    // Before candidate generation: a dynamic proxy's fat bound covers the
    // body grown by its reach, so every pair that can come into contact
    // within this step is a candidate (speculative contacts).
    void CoverStepReach(Body& body, float fixedDeltaTime) {
        const Aabb reach = TightBound(body).Expanded(StepReach(body, fixedDeltaTime));
        if (tree.FatAabb(body.proxy).Contains(reach)) return;
        tree.MoveProxy(body.proxy, reach.Expanded(kBroadphaseMargin));
        ++reinsertionsSinceStep;
    }

    void RefreshProxy(Body& body) {
        const Aabb tight = TightBound(body);
        if (tree.FatAabb(body.proxy).Contains(tight)) return;
        tree.MoveProxy(body.proxy, tight.Expanded(kBroadphaseMargin));
        ++reinsertionsSinceStep;
    }

    // Live slots whose fat bounds overlap `box`, ascending.
    const std::vector<unsigned int>& QuerySlots(const Aabb& box) const {
        queryScratch.clear();
        tree.Query(box, [&](int proxy) { queryScratch.push_back(tree.UserData(proxy)); });
        std::sort(queryScratch.begin(), queryScratch.end());
        return queryScratch;
    }

    // Candidate pairs (lo, hi) for every pair with at least one movable
    // body, in ascending lexicographic slot order — the same order the
    // pre-M32 all-pairs loop visited them in, restricted to candidates.
    void GenerateCandidatePairs() {
        candidatePairs.clear();
        for (const unsigned int slot : aliveSlots) {
            const Body& a = bodies[slot];
            if (a.rigidBody.IsStatic()) continue;
            tree.Query(tree.FatAabb(a.proxy), [&](int proxy) {
                const unsigned int other = tree.UserData(proxy);
                if (other == slot) return;
                const Body& b = bodies[other];
                // A pair of two movable bodies is found by both queries;
                // keep it from the lower slot's query only.
                if (!b.rigidBody.IsStatic() && other < slot) return;
                candidatePairs.emplace_back(std::min(slot, other), std::max(slot, other));
            });
        }
        std::sort(candidatePairs.begin(), candidatePairs.end());
    }

    BodyHandle MakeHandle(unsigned int slot) const {
        BodyHandle handle;
        handle.id = slot | (bodies[slot].generation << kSlotBits);
        return handle;
    }

    bool hasPlayerShape = false;
    Shape playerShape;

    // A member of Impl (rather than a free function taking a body list)
    // specifically so it can name `Body` without exposing this private
    // nested type outside PhysicsWorld.cpp.
    // Milestone 32: evaluates only `candidates` (the broadphase's answer for
    // the whole sweep). Any body not among them has a positive distance, so
    // it could never be the reported closest body of a hit.
    ClosestBodyResult ClosestBodyToCapsule(const std::vector<unsigned int>& candidates,
                                            const glm::vec3& segA, const glm::vec3& segB,
                                            float capsuleRadius,
                                            float bodyMotionAlpha,
                                            bool interpolateDynamicBodyMotion) const {
        ClosestBodyResult result;
        for (const unsigned int i : candidates) {
            const Body& body = bodies[i];
            const bool interpolateBody = interpolateDynamicBodyMotion && body.isDynamic;
            const bool ledger=interpolateBody && bodyMotionAlpha<1.0f && !body.motion.Segments().empty();
            const auto observed=ledger ? body.motion.Evaluate(std::clamp(double(bodyMotionAlpha),0.0,1.0)*stepDuration) : body.rigidBody;
            const glm::vec3 bodyPosition = ledger ? observed.position : interpolateBody
                ? glm::mix(body.previousPosition, body.rigidBody.position, bodyMotionAlpha)
                : body.rigidBody.position;
            const glm::quat bodyOrientation = ledger ? observed.orientation : interpolateBody
                ? glm::normalize(glm::slerp(body.previousOrientation, body.rigidBody.orientation,
                                            bodyMotionAlpha))
                : body.rigidBody.orientation;
            RigidBody sampledBody = body.rigidBody;
            sampledBody.position = bodyPosition;
            sampledBody.orientation = bodyOrientation;
            if (body.shape.type == ShapeType::Terrain) {
                if (!body.shape.terrain) continue;
                const float segmentLength = glm::length(segB - segA);
                const float minimumEndRadius = std::min(glm::length(segA - bodyPosition),
                                                        glm::length(segB - bodyPosition));
                if (minimumEndRadius - segmentLength >
                    body.shape.terrain->BoundRadius() + capsuleRadius) continue;
                // Sampling the whole capsule core, rather than just its
                // lower endpoint, also handles arbitrary capsule attitude
                // and terrain slopes without a universal up axis.
                constexpr int kSegmentSamples = 9;
                for (int sampleIndex = 0; sampleIndex < kSegmentSamples; ++sampleIndex) {
                    const float t = static_cast<float>(sampleIndex) /
                                    static_cast<float>(kSegmentSamples - 1);
                    const TerrainSample sample = SampleTerrainAtWorld(
                        *body.shape.terrain, sampledBody, glm::mix(segA, segB, t));
                    const float distance = sample.signedDistance - capsuleRadius;
                    if (distance < result.distance) {
                        result.distance = distance;
                        result.normal = sample.outwardNormal;
                        result.bodyIndex = static_cast<int>(i);
                    }
                }
                continue;
            }
            for (int part = 0; part < PrimitiveCount(body.shape); ++part) {
                const PrimitivePose primitive = PrimitiveAt(body.shape, sampledBody, part);
                CapsuleDistance capsuleDistance;
                if (primitive.shape.type == ShapeType::Sphere) {
                    capsuleDistance = CapsuleDistanceToSphere(segA, segB, capsuleRadius,
                                                               primitive.body.position,
                                                               primitive.shape.radius);
                } else if (primitive.shape.type == ShapeType::Box) {
                    capsuleDistance = CapsuleDistanceToBox(segA, segB, capsuleRadius,
                                                            primitive.body.position,
                                                            primitive.body.orientation,
                                                            primitive.shape.halfExtents);
                } else {
                    continue;
                }
                if (capsuleDistance.distance < result.distance) {
                    result.distance = capsuleDistance.distance;
                    result.normal = capsuleDistance.normal;
                    result.bodyIndex = static_cast<int>(i);
                }
            }
        }
        return result;
    }

    Body* Get(BodyHandle handle) {
        if (!handle.IsValid()) return nullptr;
        const unsigned int slot = handle.id & kSlotMask;
        if (slot >= bodies.size() || !bodies[slot].alive ||
            bodies[slot].generation != (handle.id >> kSlotBits)) {
            return nullptr;
        }
        return &bodies[slot];
    }
    const Body* Get(BodyHandle handle) const {
        if (!handle.IsValid()) return nullptr;
        const unsigned int slot = handle.id & kSlotMask;
        if (slot >= bodies.size() || !bodies[slot].alive ||
            bodies[slot].generation != (handle.id >> kSlotBits)) {
            return nullptr;
        }
        return &bodies[slot];
    }

    BodyHandle AddBody(const Shape& shape, const glm::vec3& position, const glm::quat& rotation,
                        bool isDynamic, float mass, float friction, float restitution) {
        Body body;
        body.shape = shape;
        body.boundingRadius = ShapeBoundingRadius(shape);
        ++cacheCounters.shapeRebuilds;
        body.friction = friction;
        body.restitution = restitution;
        body.isDynamic = isDynamic;
        body.alive = true;
        body.rigidBody.position = position;
        body.rigidBody.orientation = rotation;
        body.previousPosition = position;
        body.previousOrientation = rotation;
        if (isDynamic) {
            body.rigidBody.inverseMass = mass > 0.0f ? 1.0f / mass : 0.0f;
            if (shape.type == ShapeType::Sphere) {
                body.rigidBody.inverseInertiaLocal = SolidSphereInverseInertia(mass, shape.radius);
            } else if (shape.type == ShapeType::Box) {
                body.rigidBody.inverseInertiaLocal = SolidBoxInverseInertia(mass, shape.halfExtents);
            } else if (shape.type == ShapeType::CompoundBoxes) {
                body.rigidBody.inverseInertiaLocal = CompoundInverseInertia(mass, shape.boxes);
            }
        }
        // Static bodies keep inverseMass=0 / zero inverse inertia (RigidBody's own defaults),
        // which is exactly what "never moved by force or impulse" means throughout this engine.
        unsigned int slot;
        if (!freeSlots.empty()) {
            slot = freeSlots.back();
            freeSlots.pop_back();
            body.generation = (bodies[slot].generation + 1u) & ((1u << (32u - kSlotBits)) - 1u);
            bodies[slot] = body;
        } else {
            slot = static_cast<unsigned int>(bodies.size());
            bodies.push_back(body);
        }
        aliveSlots.insert(std::lower_bound(aliveSlots.begin(), aliveSlots.end(), slot), slot);
        bodies[slot].proxy = tree.CreateProxy(TightBound(bodies[slot]).Expanded(kBroadphaseMargin), slot);
        return MakeHandle(slot);
    }

    void Remove(BodyHandle handle) {
        Body* body = Get(handle);
        if (!body) return;
        const unsigned int slot = handle.id & kSlotMask;
        body->alive = false;
        tree.DestroyProxy(body->proxy);
        body->proxy = DynamicAabbTree::kNull;
        freeSlots.push_back(slot);
        const auto it = std::lower_bound(aliveSlots.begin(), aliveSlots.end(), slot);
        if (it != aliveSlots.end() && *it == slot) aliveSlots.erase(it);
    }
};

bool PhysicsWorld::Init() {
    m_impl = new Impl();
    return true;
}

PhysicsWorld::~PhysicsWorld() { Shutdown(); }

void PhysicsWorld::Shutdown() {
    delete m_impl;
    m_impl = nullptr;
}

BodyHandle PhysicsWorld::CreateStaticBox(const glm::vec3& position, const glm::vec3& halfExtents,
                                          float friction, float restitution) {
    return CreateStaticBox(position, glm::quat(1.0f, 0.0f, 0.0f, 0.0f), halfExtents, friction,
                            restitution);
}

BodyHandle PhysicsWorld::CreateStaticBox(const glm::vec3& position, const glm::quat& rotation,
                                          const glm::vec3& halfExtents, float friction,
                                          float restitution) {
    return m_impl->AddBody(Shape::Box(halfExtents), position, rotation, false, 0.0f, friction,
                            restitution);
}

BodyHandle PhysicsWorld::CreateStaticSphere(const glm::vec3& position, float radius,
                                             float friction, float restitution) {
    return m_impl->AddBody(Shape::Sphere(radius), position, glm::quat(1.0f, 0.0f, 0.0f, 0.0f),
                            false, 0.0f, friction, restitution);
}

BodyHandle PhysicsWorld::CreateStaticTerrain(const glm::vec3& position,
                                              const glm::quat& rotation,
                                              std::shared_ptr<const RadialTerrain> terrain,
                                              float friction, float restitution) {
    if (!terrain) return BodyHandle{};
    return m_impl->AddBody(Shape::Terrain(std::move(terrain)), position, rotation,
                           false, 0.0f, friction, restitution);
}

BodyHandle PhysicsWorld::CreateDynamicBox(const glm::vec3& position, const glm::vec3& halfExtents,
                                           float mass, float friction, float restitution) {
    return m_impl->AddBody(Shape::Box(halfExtents), position, glm::quat(1.0f, 0.0f, 0.0f, 0.0f),
                            true, mass, friction, restitution);
}

BodyHandle PhysicsWorld::CreateDynamicSphere(const glm::vec3& position, float radius, float mass,
                                              float friction, float restitution) {
    return m_impl->AddBody(Shape::Sphere(radius), position, glm::quat(1.0f, 0.0f, 0.0f, 0.0f), true,
                            mass, friction, restitution);
}

BodyHandle PhysicsWorld::CreateDynamicCompoundBoxes(const glm::vec3& position,
                                                     const std::vector<CompoundBox>& boxes,
                                                     float mass, float friction, float restitution) {
    if (boxes.empty() || mass <= 0.0f) return BodyHandle{};
    for (const CompoundBox& box : boxes) {
        if (box.halfExtents.x <= 0.0f || box.halfExtents.y <= 0.0f || box.halfExtents.z <= 0.0f) {
            return BodyHandle{};
        }
    }
    return m_impl->AddBody(Shape::Compound(boxes), position,
                            glm::quat(1.0f, 0.0f, 0.0f, 0.0f), true,
                            mass, friction, restitution);
}

void PhysicsWorld::DestroyBody(BodyHandle handle) {
    m_impl->Remove(handle);
}

std::size_t PhysicsWorld::AliveBodyCount() const {
    return m_impl->aliveSlots.size();
}

const std::vector<PhysicsWorld::DebugContact>& PhysicsWorld::LastStepContacts() const {
    return m_impl->lastStepContacts;
}

std::size_t PhysicsWorld::DynamicBodyCount() const {
    std::size_t count = 0;
    for (const unsigned int slot : m_impl->aliveSlots) {
        if (m_impl->bodies[slot].isDynamic) ++count;
    }
    return count;
}

void PhysicsWorld::ApplyLinearAcceleration(BodyHandle handle, const glm::vec3& acceleration,
                                            float fixedDeltaTime) {
    Impl::Body* body = m_impl->Get(handle);
    if (!body || body->rigidBody.IsStatic()) return;
    body->rigidBody.linearVelocity += acceleration * fixedDeltaTime;
}

void PhysicsWorld::ApplyForce(BodyHandle handle, const glm::vec3& force) {
    Impl::Body* body = m_impl->Get(handle);
    if (!body || body->rigidBody.IsStatic()) return;
    body->rigidBody.ApplyForce(force);
}

void PhysicsWorld::ApplyTorque(BodyHandle handle, const glm::vec3& torque) {
    Impl::Body* body = m_impl->Get(handle);
    if (!body || body->rigidBody.IsStatic()) return;
    body->rigidBody.ApplyTorque(torque);
}

bool PhysicsWorld::IsDynamicBody(BodyHandle handle) const {
    const Impl::Body* body = m_impl->Get(handle);
    return body && body->isDynamic;
}

float PhysicsWorld::GetMass(BodyHandle handle) const {
    const Impl::Body* body = m_impl->Get(handle);
    return body && body->isDynamic && body->rigidBody.inverseMass > 0.0f
               ? 1.0f / body->rigidBody.inverseMass
               : 0.0f;
}

void PhysicsWorld::ApplyLinearImpulse(BodyHandle handle, const glm::vec3& impulse) {
    Impl::Body* body = m_impl->Get(handle);
    if (!body || !body->isDynamic) return;
    body->rigidBody.ApplyLinearImpulse(impulse);
}

void PhysicsWorld::ApplyImpulseAtPoint(BodyHandle handle, const glm::vec3& impulse,
                                       const glm::vec3& worldPoint) {
    Impl::Body* body = m_impl->Get(handle);
    if (!body || !body->isDynamic) return;
    body->rigidBody.ApplyImpulseAtPoint(impulse, worldPoint);
}

glm::vec3 PhysicsWorld::GetLinearVelocity(BodyHandle handle) const {
    const Impl::Body* body = m_impl->Get(handle);
    return body ? body->rigidBody.linearVelocity : glm::vec3(0.0f);
}

void PhysicsWorld::SetLinearVelocity(BodyHandle handle, const glm::vec3& velocity) {
    Impl::Body* body = m_impl->Get(handle);
    if (body) body->rigidBody.linearVelocity = velocity;
}

glm::vec3 PhysicsWorld::GetAngularVelocity(BodyHandle handle) const {
    const Impl::Body* body = m_impl->Get(handle);
    return body ? body->rigidBody.angularVelocity : glm::vec3(0.0f);
}

glm::mat3 PhysicsWorld::GetInertiaWorld(BodyHandle handle) const {
    const Impl::Body* body = m_impl->Get(handle);
    if (!body || !body->isDynamic) return glm::mat3(0.0f);
    return glm::inverse(body->rigidBody.InverseInertiaWorld());
}

float PhysicsWorld::GetBodySupportDistance(BodyHandle handle, const glm::vec3& worldDirection) const {
    const Impl::Body* body = m_impl->Get(handle);
    const float directionLength = glm::length(worldDirection);
    if (!body || directionLength < 1.0e-6f) return 0.0f;

    const glm::vec3 direction = worldDirection / directionLength;
    float maximum = 0.0f;
    for (int part = 0; part < PrimitiveCount(body->shape); ++part) {
        const PrimitivePose primitive = PrimitiveAt(body->shape, body->rigidBody, part);
        float extent = 0.0f;
        if (primitive.shape.type == ShapeType::Sphere) {
            extent = primitive.shape.radius;
        } else if (primitive.shape.type == ShapeType::Box) {
            const glm::vec3 localDirection =
                glm::conjugate(glm::normalize(primitive.body.orientation)) * direction;
            extent = glm::dot(glm::abs(localDirection), primitive.shape.halfExtents);
        } else if (primitive.shape.type == ShapeType::Terrain && primitive.shape.terrain) {
            // Exact directional support of an arbitrary radial height
            // function would require global optimization. Its immutable
            // radius bound is conservative for this separation query.
            extent = primitive.shape.terrain->BoundRadius();
        }
        maximum = std::max(maximum,
                            glm::dot(primitive.body.position - body->rigidBody.position,
                                     direction) + extent);
    }
    return maximum;
}

float PhysicsWorld::GetPlayerShapeMaxSupportDistance() const {
    if (!m_impl->hasPlayerShape) return 0.0f;
    return m_impl->playerShape.radius + m_impl->playerShape.halfHeight;
}

void PhysicsWorld::SetAngularVelocity(BodyHandle handle, const glm::vec3& angularVelocity) {
    Impl::Body* body = m_impl->Get(handle);
    if (body) body->rigidBody.angularVelocity = angularVelocity;
}

void PhysicsWorld::Step(float fixedDeltaTime) {
    Impl& w = *m_impl;
    const Clock::time_point stepStart = Clock::now();
    w.stats = StepStats{};
    const auto cachesBefore = w.cacheCounters;
    const ContactGeometryDiagnostics geometryBefore = GetContactGeometryDiagnostics();

    // 1) Velocity from this step's force/torque accumulators (M12). Gravity
    // is already in linearVelocity via the caller's ApplyLinearAcceleration.
    // The start-of-step pose is kept for player sweeps and presentation.
    std::size_t movable = 0;
    for (const unsigned int slot : w.aliveSlots) {
        Impl::Body& body = w.bodies[slot];
        if (!body.rigidBody.IsStatic()) ++movable;
        if (!body.isDynamic) continue;
        body.motion.Clear();
        body.previousPosition = body.rigidBody.position;
        body.previousOrientation = body.rigidBody.orientation;
        // Capture the old endpoint before integration. CurrentBound itself is
        // keyed by represented pose, so a later correction cannot reuse it.
        w.CurrentBound(body);
        body.previousBound = body.currentBound;
        IntegrateRigidBodyVelocity(body.rigidBody, fixedDeltaTime);
        w.CoverStepReach(body, fixedDeltaTime);
    }
    w.stats.bodies = w.aliveSlots.size();
    w.stats.dynamicBodies = movable;
    w.stats.possiblePairs = movable * (movable - (movable > 0 ? 1 : 0)) / 2 +
                            movable * (w.aliveSlots.size() - movable);

    // 2) Broadphase: every fat bound contains its body's current pose
    // (refreshed at the end of the previous Step and by ResetBody), so every
    // touching pair is among the candidates. Static-static pairs never are.
    const Clock::time_point broadphaseStart = Clock::now();
    w.GenerateCandidatePairs();
    w.stats.candidatePairs = w.candidatePairs.size();
    const Clock::time_point narrowphaseStart = Clock::now();

    // 3) Narrowphase at the current poses — the sole authority on contact.
    w.solver.Clear();
    w.lastStepContacts.clear();
    w.pendingCache.clear();
    w.startContacts.clear();
    w.separatedPairs.clear();
    w.cacheUsed.assign(w.contactCache.size(), 0);
    for (const auto& [slotA, slotB] : w.candidatePairs) {
        Impl::Body& a = w.bodies[slotA];
        Impl::Body& b = w.bodies[slotB];
        const float friction = std::sqrt(std::max(a.friction, 0.0f) * std::max(b.friction, 0.0f));
        // Speculative margin: the distance this pair's surfaces can close
        // within the step at their post-force velocities (relative linear
        // motion plus each body's rotation at its bounding radius). Any
        // contact within it is generated now, before it can penetrate; at
        // rest on a support that is g*dt^2 (2.7 mm at 60 Hz, 9.81 m/s^2).
        const float margin =
            (glm::length(a.rigidBody.linearVelocity - b.rigidBody.linearVelocity) +
             glm::length(a.rigidBody.angularVelocity) * a.boundingRadius +
             glm::length(b.rigidBody.angularVelocity) * b.boundingRadius) *
            fixedDeltaTime;
        int pairPoints = 0;
        const auto& orientationA = w.Orientation(a);
        const auto& orientationB = w.Orientation(b);
        const glm::dmat3 inverseA = glm::transpose(orientationA.rotation);
        for (int partA = 0; partA < PrimitiveCount(a.shape); ++partA) {
            const PrimitivePose childA = PrimitiveAt(a.shape, a.rigidBody, partA, &orientationA);
            for (int partB = 0; partB < PrimitiveCount(b.shape); ++partB) {
                const PrimitivePose childB = PrimitiveAt(b.shape, b.rigidBody, partB, &orientationB);
                const ContactManifold manifold =
                    ComputeContacts(childA, childB, margin, &orientationA, &orientationB);
                const ContactKey key{slotA, slotB, a.generation, b.generation, partA, partB};
                const auto range = std::equal_range(
                    w.contactCache.begin(), w.contactCache.end(), CachedContact{key, {}, {}, 0.0f, {}},
                    [](const CachedContact& x, const CachedContact& y) { return x.key < y.key; });
                bool touchingManifold=false;
                for (int p=0;p<manifold.count;++p) {
                    const auto& c=manifold.points[p];
                    touchingManifold=touchingManifold || (c.hasLocalAnchors ? c.signedSeparation<=0 : c.penetration>=0);
                }
                if(!touchingManifold && manifold.count)
                    touchingManifold=ComputeContacts(childA,childB,0,&orientationA,&orientationB).count>0;
                for (int p = 0; p < manifold.count; ++p) {
                    Contact contact = manifold.points[p];
                    if (!contact.hit) continue;
                    // Warm start from the nearest unused cached point of the
                    // same bodies/primitives (same generations: a reused slot
                    // never inherits a previous occupant's impulses).
                    const glm::dvec3 anchor = contact.hasLocalAnchors ? contact.localAnchorA :
                        inverseA * (glm::dvec3(contact.point) - glm::dvec3(a.rigidBody.position));
                    float warmNormal = 0.0f;
                    glm::vec3 warmTangent(0.0f);
                    std::ptrdiff_t best = -1;
                    double bestDistance = kWarmStartAnchorDistance;
                    for (auto it = range.first; it != range.second; ++it) {
                        const std::ptrdiff_t index = it - w.contactCache.begin();
                        if (w.cacheUsed[static_cast<std::size_t>(index)] || !it->key.SameBodies(key) ||
                            glm::dot(it->normal, contact.normal) < kWarmStartNormalDot) continue;
                        const double distance = glm::distance(it->localAnchorA, anchor);
                        if (distance < bestDistance) {
                            bestDistance = distance;
                            best = index;
                        }
                    }
                    if (best >= 0) {
                        w.cacheUsed[static_cast<std::size_t>(best)] = 1;
                        warmNormal = w.contactCache[static_cast<std::size_t>(best)].normalImpulse;
                        warmTangent = w.contactCache[static_cast<std::size_t>(best)].tangentImpulse;
                    }
                    // A separated, newly encountered pair is handled at TOI.
                    // Existing cached support retains its gap-closing constraint.
                    const double gap=contact.hasLocalAnchors ? contact.signedSeparation : -double(contact.penetration);
                    if (gap>0 && best<0 && !touchingManifold) {
                        const std::array<unsigned,4> pair{slotA,slotB,unsigned(partA),unsigned(partB)};
                        if(w.separatedPairs.empty() || w.separatedPairs.back()!=pair) w.separatedPairs.push_back(pair);
                        continue;
                    }
                    const auto constraint=w.solver.Constraints().size();
                    w.solver.AddContact(a.rigidBody,b.rigidBody,contact,friction,0,
                        warmNormal,warmTangent,&orientationA.rotation,&orientationB.rotation);
                    if(w.solver.Constraints().size()>constraint) {
                        w.pendingCache.push_back({key,anchor,contact.normal,0,glm::vec3(0)});
                        w.startContacts.push_back({slotA,slotB,constraint,friction,warmNormal,warmTangent,
                            best<0 && gap<=0 && Impl::NormalSpeed(contact,a.rigidBody,b.rigidBody)<-0.5});
                    }
                    w.lastStepContacts.push_back({contact.point, contact.normal, contact.penetration});
                    ++pairPoints;
                }
            }
        }
        if (pairPoints > 0) ++w.stats.collidingPairs;
    }
    w.stats.contactPoints = w.lastStepContacts.size();
    const Clock::time_point solverStart = Clock::now();

    // 4) Accumulated-impulse velocity solve (src/ContactSolver.h), then
    // positions from the solved velocities, then direct penetration removal.
    w.ResolveInitialImpacts(fixedDeltaTime);
    w.supportPairs.clear();
    for(const auto& c:w.startContacts) if(!c.newImpact) {
        const auto& key=w.pendingCache[c.constraint].key;
        w.supportPairs.push_back({c.a,c.b,unsigned(key.partA),unsigned(key.partB)});
    }
    std::sort(w.supportPairs.begin(),w.supportPairs.end());
    w.supportPairs.erase(std::unique(w.supportPairs.begin(),w.supportPairs.end()),w.supportPairs.end());
    w.solver.Prepare(fixedDeltaTime);
    w.solver.SolveVelocities();
    // Remember this step's converged impulses for the next step's warm start.
    const std::vector<ContactConstraint>& solved = w.solver.Constraints();
    for (std::size_t i = 0; i < solved.size() && i < w.pendingCache.size(); ++i) {
        w.pendingCache[i].normalImpulse = solved[i].normalImpulse;
        w.pendingCache[i].tangentImpulse = solved[i].tangentImpulse;
    }
    std::stable_sort(w.pendingCache.begin(), w.pendingCache.end(),
                     [](const CachedContact& x, const CachedContact& y) { return x.key < y.key; });
    std::swap(w.contactCache, w.pendingCache);
    w.AdvanceImpacts(fixedDeltaTime);
    for (const unsigned int slot:w.aliveSlots) {
        auto& body=w.bodies[slot];
        if(body.isDynamic) w.solver.UpdatePreparedRotation(body.rigidBody,w.Orientation(body).rotation);
    }
    w.solver.SolvePositions();
    const Clock::time_point solverEnd = Clock::now();

    // 5) Keep every dynamic proxy's fat bound around its previous-to-current
    // motion for the player's sweeps and the next step's candidates.
    for (const unsigned int slot : w.aliveSlots) {
        Impl::Body& body = w.bodies[slot];
        if (body.isDynamic) w.RefreshProxy(body);
    }
    w.stats.proxyReinsertions = w.reinsertionsSinceStep;
    w.reinsertionsSinceStep = 0;
    w.stats.treeHeight = w.tree.Height();
    w.stats.orientationCacheHits = w.cacheCounters.orientationHits-cachesBefore.orientationHits;
    w.stats.orientationCacheRebuilds = w.cacheCounters.orientationRebuilds-cachesBefore.orientationRebuilds;
    w.stats.boundCacheHits = w.cacheCounters.boundHits-cachesBefore.boundHits;
    w.stats.boundCacheRebuilds = w.cacheCounters.boundRebuilds-cachesBefore.boundRebuilds;
    w.stats.shapeCacheRebuilds = w.cacheCounters.shapeRebuilds-cachesBefore.shapeRebuilds;
    w.stats.solverFrameBuilds = w.solver.FrameBuilds();
    w.stats.geometryCacheAllocations = w.cacheCounters.allocations-cachesBefore.allocations+w.solver.FrameAllocations();
    w.stats.geometryCacheAllocatedBytes = w.cacheCounters.allocatedBytes-cachesBefore.allocatedBytes+w.solver.FrameAllocatedBytes();
    w.stats.solverFrameNodeRequests = w.solver.FrameNodeRequests();
    w.stats.geometryCacheBytes = w.CacheBytes();
    const Clock::time_point stepEnd = Clock::now();
    w.stats.broadphaseMilliseconds = MillisecondsBetween(broadphaseStart, narrowphaseStart) +
                                     MillisecondsBetween(solverEnd, stepEnd);
    w.stats.narrowphaseMilliseconds = MillisecondsBetween(narrowphaseStart, solverStart);
    w.stats.solverMilliseconds = MillisecondsBetween(solverStart, solverEnd);
    w.stats.totalMilliseconds = MillisecondsBetween(stepStart, stepEnd);
    const ContactGeometryDiagnostics geometryAfter = GetContactGeometryDiagnostics();
    w.stats.geometryPredicates = geometryAfter.predicates - geometryBefore.predicates;
    w.stats.geometryExactFallbacks = geometryAfter.exactFallbacks - geometryBefore.exactFallbacks;
    w.stats.geometryUnresolved = geometryAfter.unresolved - geometryBefore.unresolved;
    w.stats.geometryNumericGapFallbacks = geometryAfter.numericGapFallbacks - geometryBefore.numericGapFallbacks;
}

const PhysicsWorld::StepStats& PhysicsWorld::LastStepStats() const { return m_impl->stats; }

std::vector<BodyHandle> PhysicsWorld::QueryBodiesInAabb(const glm::vec3& min, const glm::vec3& max) const {
    std::vector<BodyHandle> result;
    for (const unsigned int slot : m_impl->QuerySlots(Aabb{glm::min(min, max), glm::max(min, max)})) {
        result.push_back(m_impl->MakeHandle(slot));
    }
    return result;
}

bool PhysicsWorld::GetBodyBroadphaseBounds(BodyHandle handle, glm::vec3& outMin, glm::vec3& outMax) const {
    const Impl::Body* body = m_impl->Get(handle);
    if (!body) return false;
    const Aabb& fat = m_impl->tree.FatAabb(body->proxy);
    outMin = fat.min;
    outMax = fat.max;
    return true;
}

bool PhysicsWorld::GetBodyGeometryCacheState(BodyHandle handle, GeometryCacheState& state) const {
    const Impl::Body* body = m_impl->Get(handle);
    if (!body) return false;
    const auto& current = body->currentBound;
    const auto& previous = body->previousBound;
    state.currentPose = {current.position,current.orientation};
    state.previousPose = {previous.position,previous.orientation};
    state.currentMin = current.bound.min; state.currentMax = current.bound.max;
    state.previousMin = previous.bound.min; state.previousMax = previous.bound.max;
    state.currentValid = current.valid; state.previousValid = previous.valid;
    state.boundingRadius = body->boundingRadius;
    return true;
}

std::vector<PhysicsWorld::CollidingPair> PhysicsWorld::FindCollidingPairs() const {
    Impl& w = *m_impl;
    // Same candidate generation and narrowphase as Step, without solving.
    w.GenerateCandidatePairs();
    std::vector<CollidingPair> result;
    for (const auto& [slotA, slotB] : w.candidatePairs) {
        Impl::Body& a = w.bodies[slotA];
        Impl::Body& b = w.bodies[slotB];
        const auto& orientationA = w.Orientation(a);
        const auto& orientationB = w.Orientation(b);
        int points = 0;
        for (int partA = 0; partA < PrimitiveCount(a.shape); ++partA) {
            const PrimitivePose childA = PrimitiveAt(a.shape, a.rigidBody, partA, &orientationA);
            for (int partB = 0; partB < PrimitiveCount(b.shape); ++partB) {
                const PrimitivePose childB = PrimitiveAt(b.shape, b.rigidBody, partB, &orientationB);
                const ContactManifold manifold =
                    ComputeContacts(childA, childB, 0.0f, &orientationA, &orientationB);
                for (int p = 0; p < manifold.count; ++p) {
                    if (manifold.points[p].hit) ++points;
                }
            }
        }
        if (points > 0) result.push_back({w.MakeHandle(slotA), w.MakeHandle(slotB), points});
    }
    return result;
}

std::vector<BodyHandle> PhysicsWorld::AliveBodies() const {
    std::vector<BodyHandle> result;
    result.reserve(m_impl->aliveSlots.size());
    for (const unsigned int slot : m_impl->aliveSlots) result.push_back(m_impl->MakeHandle(slot));
    return result;
}

bool PhysicsWorld::GetBodyShape(BodyHandle handle, Shape& outShape, BodyTransform& outPose) const {
    const Impl::Body* body = m_impl->Get(handle);
    if (!body) return false;
    outShape = body->shape;
    outPose.position = body->rigidBody.position;
    outPose.rotation = body->rigidBody.orientation;
    return true;
}

BodyTransform PhysicsWorld::GetTransform(BodyHandle handle) const {
    BodyTransform result;
    const Impl::Body* body = m_impl->Get(handle);
    if (!body) return result;
    result.position = body->rigidBody.position;
    result.rotation = body->rigidBody.orientation;
    return result;
}

BodyTransform PhysicsWorld::GetPreviousTransform(BodyHandle handle) const {
    BodyTransform result;
    const Impl::Body* body = m_impl->Get(handle);
    if (!body) return result;
    if (body->isDynamic) {
        result.position = body->previousPosition;
        result.rotation = body->previousOrientation;
    } else {
        result.position = body->rigidBody.position;
        result.rotation = body->rigidBody.orientation;
    }
    return result;
}

std::vector<BodyBox> PhysicsWorld::GetBodyBoxes(BodyHandle handle) const {
    const Impl::Body* body = m_impl->Get(handle);
    if (!body) return {};
    return BoxesAt(body->shape, body->rigidBody.position, body->rigidBody.orientation);
}

std::vector<BodyBox> PhysicsWorld::GetPreviousBodyBoxes(BodyHandle handle) const {
    const Impl::Body* body = m_impl->Get(handle);
    if (!body) return {};
    return BoxesAt(body->shape,
                   body->isDynamic ? body->previousPosition : body->rigidBody.position,
                   body->isDynamic ? body->previousOrientation : body->rigidBody.orientation);
}

void PhysicsWorld::ResetBody(BodyHandle handle, const glm::vec3& position,
                              const glm::quat& rotation) {
    Impl::Body* body = m_impl->Get(handle);
    if (!body) return;
    body->rigidBody.position = position;
    body->rigidBody.orientation = rotation;
    body->previousPosition = position;
    body->motion.Clear();
    body->previousOrientation = rotation;
    body->rigidBody.linearVelocity = glm::vec3(0.0f);
    body->rigidBody.angularVelocity = glm::vec3(0.0f);
    body->rigidBody.ClearAccumulators();
    m_impl->RefreshProxy(*body);
}

bool PhysicsWorld::CreatePlayerShape(float radius, float halfHeight) {
    m_impl->playerShape = Shape::Capsule(radius, halfHeight);
    m_impl->hasPlayerShape = true;
    return true;
}

void PhysicsWorld::DestroyPlayerShape() { m_impl->hasPlayerShape = false; }

ShapeSweepHit PhysicsWorld::SweepPlayerShape(const glm::vec3& fromCenter, const glm::quat& rotation,
                                              const glm::vec3& displacement,
                                              bool interpolateDynamicBodyMotion,
                                              float bodyMotionStart,
                                              float bodyMotionEnd) const {
    ShapeSweepHit result;
    if (!m_impl->hasPlayerShape) return result;

    const float displacementLength = glm::length(displacement);
    if (displacementLength < 1.0e-6f && !interpolateDynamicBodyMotion) return result;

    const glm::vec3 localSegA(0.0f, -m_impl->playerShape.halfHeight, 0.0f);
    const glm::vec3 localSegB(0.0f, m_impl->playerShape.halfHeight, 0.0f);
    const float capsuleRadius = m_impl->playerShape.radius;

    auto worldSegmentAt = [&](const glm::vec3& center) {
        return std::make_pair(center + rotation * localSegA, center + rotation * localSegB);
    };
    // Milestone 32: one broadphase query for the whole swept capsule; every
    // evaluation below then tests only those bodies. Dynamic bodies' fat
    // bounds already cover their previous-to-current motion.
    Aabb sweptBound;
    {
        const auto [a0, b0] = worldSegmentAt(fromCenter);
        const auto [a1, b1] = worldSegmentAt(fromCenter + displacement);
        sweptBound.min = glm::min(glm::min(a0, b0), glm::min(a1, b1));
        sweptBound.max = glm::max(glm::max(a0, b0), glm::max(a1, b1));
        sweptBound = sweptBound.Expanded(capsuleRadius + kSweepQueryEpsilon);
    }
    const std::vector<unsigned int> candidates = m_impl->QuerySlots(sweptBound);
    auto evaluateAt = [&](float t) {
        const glm::vec3 center = fromCenter + displacement * t;
        const auto [segA, segB] = worldSegmentAt(center);
        const float bodyMotionAlpha = glm::mix(bodyMotionStart, bodyMotionEnd, t);
        return m_impl->ClosestBodyToCapsule(candidates, segA, segB, capsuleRadius, bodyMotionAlpha,
                                            interpolateDynamicBodyMotion);
    };

    // Already touching/overlapping at the very start of the sweep — report
    // an immediate zero-distance hit rather than marching forward, mirroring
    // the "already touching" case a grounded move-and-slide step produces
    // routinely (see docs/ARCHITECTURE.md, "Contact normal correctness and
    // the 'already touching' case," law #13 — this normal is likewise
    // unconditional, never derived from travel direction).
    const ClosestBodyResult startResult = evaluateAt(0.0f);
    if (startResult.bodyIndex >= 0 && startResult.distance <= 0.0f) {
        result.hit = true;
        result.distance = 0.0f;
        result.normal = startResult.normal;
        result.hitBody = m_impl->MakeHandle(static_cast<unsigned int>(startResult.bodyIndex));
        return result;
    }

    // March forward in substeps looking for the first t where the capsule
    // starts overlapping something, then refine that bracket by bisection.
    // Per-step displacements in this engine are always small (a fraction
    // of a meter — see docs/ARCHITECTURE.md's move-and-slide/ground-probe
    // distances), so a modest fixed substep count plus a short bisection
    // pass gives ample precision without needing closed-form continuous
    // collision detection for every shape pair.
    constexpr int kSubsteps = 24;
    constexpr int kBisectionIterations = 20;
    std::vector<float> divisions{0,1};
    if(interpolateDynamicBodyMotion && bodyMotionEnd>bodyMotionStart && m_impl->stepDuration>0)
        for(auto slot:candidates) for(const auto& segment:m_impl->bodies[slot].motion.Segments()) {
            const float t=(float(segment.end/m_impl->stepDuration)-bodyMotionStart)/(bodyMotionEnd-bodyMotionStart);
            if(t>0 && t<1) divisions.push_back(t);
        }
    std::sort(divisions.begin(),divisions.end());
    divisions.erase(std::unique(divisions.begin(),divisions.end()),divisions.end());
    float previousT = 0.0f;
    for(std::size_t interval=1;interval<divisions.size();++interval)
    for (int step = 1; step <= kSubsteps; ++step) {
        const float t=glm::mix(divisions[interval-1],divisions[interval],float(step)/kSubsteps);
        const ClosestBodyResult stepResult = evaluateAt(t);
        if (stepResult.bodyIndex >= 0 && stepResult.distance <= 0.0f) {
            float lo = previousT;
            float hi = t;
            ClosestBodyResult refined = stepResult;
            for (int iteration = 0; iteration < kBisectionIterations; ++iteration) {
                const float mid = (lo + hi) * 0.5f;
                const ClosestBodyResult midResult = evaluateAt(mid);
                if (midResult.bodyIndex >= 0 && midResult.distance <= 0.0f) {
                    hi = mid;
                    refined = midResult;
                } else {
                    lo = mid;
                }
            }
            result.hit = true;
            result.distance = lo * displacementLength;
            result.normal = refined.normal;
            result.hitBody = m_impl->MakeHandle(static_cast<unsigned int>(refined.bodyIndex));
            return result;
        }
        previousT = t;
    }

    return result;  // no hit across the entire displacement
}
