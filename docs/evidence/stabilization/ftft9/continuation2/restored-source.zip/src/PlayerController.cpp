#include "PlayerController.h"

#include <algorithm>
#include <cmath>
#include <stdexcept>

#include <glm/gtc/constants.hpp>
#include <glm/gtc/matrix_transform.hpp>

#include "GravityField.h"
#include "LightTransforms.h"
#include "PhysicsWorld.h"
#include "StepClimb.h"
#include "Window.h"

namespace {

// Physical tuning. Explicit and small in number, per the brief — no
// acceleration curves, no sprint, no crouch.
constexpr float kCapsuleRadius = 0.3f;
constexpr float kCapsuleHalfHeight = 0.6f;    // total capsule height: 1.8m
constexpr float kEyeHeightAboveCenter = 0.7f;
constexpr float kMoveSpeed = 4.0f;            // m/s, walking pace
constexpr float kJumpSpeed = 5.0f;            // m/s, imparted opposite the sampled gravity direction

// Milestone 10: ground acceleration/deceleration model. Replaces the old
// instant "snap to desired tangential velocity" with a clamped-delta
// approach — the standard, simplest way to get smooth accel/decel with
// deliberate (not merely friction-shaped) direction reversal: reversing
// direction needs a delta of up to 2*kMoveSpeed, capped by the same rate
// as an ordinary stop, so it takes longer than accelerating from rest,
// exactly the "brake, then go the other way" feel a responsive controller
// should have. kGroundDeceleration is higher than kGroundAcceleration
// deliberately — stopping/reversing reads as snappier than getting up to
// speed, matching most conventional character controllers.
constexpr float kGroundAcceleration = 20.0f;   // m/s^2; reaches kMoveSpeed from rest in 0.2s
constexpr float kGroundDeceleration = 28.0f;   // m/s^2; stops from kMoveSpeed in ~0.14s

// Milestone 10: modest, momentum-preserving air control. Never replaces
// the airborne velocity vector (see "Velocity continuity while airborne,"
// unchanged) — only ever adds a small nudge toward kMoveSpeed in the
// current input direction, and only up to kMoveSpeed's worth of speed IN
// that direction specifically; existing momentum already exceeding that
// (e.g. a fast jump-and-coast) is never reduced. The classic bounded
// "air-accelerate" shape, not a full ground-style acceleration model.
constexpr float kAirAcceleration = 8.0f;  // m/s^2

// Milestone 10: automatic step-up/step-down (see src/StepClimb.h). Chosen
// generously enough to comfortably clear the flying primitive's own edge
// (its full box height is 0.5m — see Application.cpp's
// kFlyingPrimitiveHalfExtents — so it becomes naturally boardable while
// walking, per the brief) while staying well short of anything that should
// still require a jump.
constexpr float kMaxStepHeight = 0.55f;

// Mouse look, matching Milestones 2-4.
constexpr float kMouseSensitivity = 0.12f;  // degrees per pixel of mouse motion
constexpr float kMaxPitchDegrees = 89.0f;
constexpr float kFovDegrees = 70.0f;
constexpr float kNearPlane = 0.1f;
constexpr float kFarPlane = 500.0f;

// Third-person follow offset. Fixed, not smoothed or collision-checked —
// see docs/ARCHITECTURE.md, "Camera and look controls."
constexpr float kCameraFollowDistance = 4.0f;
constexpr float kCameraHeightOffset = 1.0f;

// Judas's own minimal movement resolution: sweep, stop just short of a hit,
// slide the remainder along the surface, repeat a few times. Not a general
// physics solver — just enough iterations to handle "hit one surface, then
// slide into a second" without visibly getting stuck.
constexpr int kMaxSlideIterations = 4;
constexpr float kSkinMargin = 0.02f;           // stay this far from a surface after moving
constexpr float kGroundProbeDistance = 0.15f;  // how far past the capsule to look for support
constexpr float kMinGroundDot = 0.643f;        // cos(~50 degrees): matches Milestone 4's slope limit
constexpr float kAscendingVelocityEpsilon = 1.0e-4f;  // suppress rotated-frame roundoff

// Milestone 7-B: caps how fast the player's local frame can reorient in
// response to a changing effective gravity direction — see
// UpdateFrameOrientation for why this is needed now (GravityResolver can
// swing the blended direction quickly near the edge of a zone's
// influence) and why it's a rotation-rate cap rather than a
// gravity-magnitude threshold.
constexpr float kMaxReorientationDegreesPerSecond = 120.0f;

// Returns the shortest-arc rotation that takes unit vector `from` to unit
// vector `to`. Used once per fixed step to keep the player's local frame
// tracking a changing gravity direction — see UpdateFrameOrientation. Not a
// general quaternion-math utility; this is the one rotation this class
// needs.
glm::quat RotationBetweenUnitVectors(const glm::vec3& from, const glm::vec3& to) {
    const float d = std::clamp(glm::dot(from, to), -1.0f, 1.0f);
    if (d < -0.9999f) {
        // Exactly opposite: any axis perpendicular to `from` works.
        const glm::vec3 axis = std::abs(from.x) < 0.9f
                                    ? glm::cross(from, glm::vec3(1.0f, 0.0f, 0.0f))
                                    : glm::cross(from, glm::vec3(0.0f, 1.0f, 0.0f));
        return glm::angleAxis(glm::pi<float>(), glm::normalize(axis));
    }
    const glm::vec3 cross = glm::cross(from, to);
    const float sine = glm::length(cross);
    if (sine < 1.0e-7f) {
        return glm::quat(1.0f, 0.0f, 0.0f, 0.0f);  // indistinguishable at float precision
    }
    // atan2(cross magnitude, dot) preserves small rotations. An earlier
    // dot > 0.9999 shortcut suppressed changes below ~0.81 degrees, so on
    // a sphere the view frame held for several fixed steps then snapped.
    return glm::angleAxis(std::atan2(sine, d), cross / sine);
}

}  // namespace

PlayerController::PlayerController(const glm::vec3& spawnCenterPosition, float spawnYawDegrees)
    : m_position(spawnCenterPosition),
      m_frameOrientation(1.0f, 0.0f, 0.0f, 0.0f),
      m_previousPosition(spawnCenterPosition),
      m_previousOrientation(1.0f, 0.0f, 0.0f, 0.0f),
      m_yaw(spawnYawDegrees),
      m_spawnPosition(spawnCenterPosition),
      m_spawnYawDegrees(spawnYawDegrees) {}

bool PlayerController::Spawn(PhysicsWorld& physics) {
    return physics.CreatePlayerShape(kCapsuleRadius, kCapsuleHalfHeight);
}

void PlayerController::Destroy(PhysicsWorld& physics) {
    physics.DestroyPlayerShape();
}

void PlayerController::SetFluidParameters(float density, float fluidDrag, float swimAcceleration) {
    if (!(density > 0.0f) || !std::isfinite(density) || !(fluidDrag >= 0.0f) ||
        !std::isfinite(fluidDrag) || !(swimAcceleration >= 0.0f) || !std::isfinite(swimAcceleration))
        throw std::invalid_argument("player fluid parameters require finite positive density and nonnegative drag/propulsion");
    m_density = density;
    m_fluidDrag = fluidDrag;
    m_swimAcceleration = swimAcceleration;
}

void PlayerController::SetFluidSample(const PlayerFluidSample& sample) {
    const auto finite = [](const glm::vec3& v) {
        return std::isfinite(v.x) && std::isfinite(v.y) && std::isfinite(v.z);
    };
    if (!(sample.immersion >= 0.0f && sample.immersion <= 1.0f) ||
        !(sample.density >= 0.0f) || !std::isfinite(sample.density) ||
        !finite(sample.velocity) || !finite(sample.acceleration) ||
        (sample.immersion > 0.0f && !(sample.density > 0.0f)))
        throw std::invalid_argument("player fluid sample requires bounded immersion and a finite liquid field");
    m_fluidSample = sample;
}

void PlayerController::UpdateFrameInput(Window& window) {
    int mouseDeltaX = 0;
    int mouseDeltaY = 0;
    window.GetMouseDelta(mouseDeltaX, mouseDeltaY);

    // Not scaled by deltaTime — relative mouse deltas already represent
    // motion since the last poll (see Milestone 2/3's Camera for the full
    // reasoning), independent of frame rate as-is.
    //
    // Subtracted, not added: with GetViewMatrix's yaw applied via
    // glm::angleAxis(radians(m_yaw), +Y) about a forward of (0,0,-1),
    // increasing m_yaw rotates the view toward -X — and cross(forward, up)
    // for that forward/up pair is +X, i.e. -X is left. So a positive
    // (rightward) mouse delta must *decrease* m_yaw to turn the view
    // right; the previous `+=` had the horizontal look inverted (mouse
    // right turned the camera left), reported during Milestone 7-A human
    // validation. Pitch's sign was already correct and is unchanged.
    m_yaw -= static_cast<float>(mouseDeltaX) * kMouseSensitivity;
    m_pitch -= static_cast<float>(mouseDeltaY) * kMouseSensitivity;
    m_pitch = std::clamp(m_pitch, -kMaxPitchDegrees, kMaxPitchDegrees);

    // Latch the jump request until a fixed step consumes it, so a short
    // press during a render frame with zero fixed steps isn't lost — see
    // docs/ARCHITECTURE.md, "Simulation timing."
    if (window.ConsumeJumpRequest()) {
        m_jumpRequested = true;
    }
}

glm::vec3 PlayerController::ComputeLocalUp(const glm::vec3& gravityAcceleration) const {
    const float length = glm::length(gravityAcceleration);
    if (length < 1.0e-6f) {
        // Degenerate GravityField sample (no defined direction) — hold the
        // existing frame's up rather than producing a NaN.
        return m_frameOrientation * glm::vec3(0.0f, 1.0f, 0.0f);
    }
    return -(gravityAcceleration / length);
}

void PlayerController::UpdateFrameOrientation(const glm::vec3& localUp, float fixedDeltaTime) {
    const glm::vec3 currentUp = m_frameOrientation * glm::vec3(0.0f, 1.0f, 0.0f);
    glm::quat delta = RotationBetweenUnitVectors(currentUp, localUp);

    // Cap how far the frame can reorient in one fixed step. Milestones
    // 3-7-A never needed this: a single GravityField's direction only
    // ever changed as a smooth function of position, so the full
    // per-step realignment above was already imperceptibly small change
    // to change every step. Milestone 7-B's GravityResolver breaks that
    // assumption — blending near the edge of two zones' influence, where
    // both weights are small, can shift the blended DIRECTION by a large
    // angle over a small change in position (see docs/ARCHITECTURE.md,
    // "Transition semantics," for the measured case: an 85-degree
    // single-step swing was observed and reproduced before this fix).
    // Rather than guess at some gravity-magnitude threshold below which
    // to distrust a sample — which would embed assumption about a
    // concrete GravityField's typical magnitude into supposedly
    // implementation-agnostic code, exactly what this class must not do
    // — bounding the ROTATION RATE itself needs no such assumption: it's
    // a pure kinematic limit on how fast the player's own sense of "up"
    // can physically change, regardless of why the target moved. Chosen
    // generously relative to ordinary gameplay (walking around this
    // demo's sphere at full speed turns local up at roughly 11
    // degrees/second) so it is never perceptible as sluggishness there,
    // while still meaningfully bounding a transition-region swing.
    const float maxRadiansThisStep = glm::radians(kMaxReorientationDegreesPerSecond) * fixedDeltaTime;
    const float deltaAngle = glm::angle(delta);
    if (deltaAngle > maxRadiansThisStep) {
        delta = glm::angleAxis(maxRadiansThisStep, glm::axis(delta));
    }

    m_frameOrientation = glm::normalize(delta * m_frameOrientation);
}

glm::vec3 PlayerController::ComputeInputDirection(const Window& window,
                                                   const glm::vec3& localUp) const {
    // The look-relative reference frame, yawed by mouse input but not
    // pitched — so looking up/down doesn't tilt ground movement off the
    // tangent plane. This mirrors Milestone 4's "flat forward," now
    // expressed relative to the current LOCAL frame instead of world Y, so
    // it stays correct as that frame rotates around the sphere.
    const glm::quat yawedFrame =
        m_frameOrientation * glm::angleAxis(glm::radians(m_yaw), glm::vec3(0.0f, 1.0f, 0.0f));
    const glm::vec3 forward = glm::normalize(yawedFrame * glm::vec3(0.0f, 0.0f, -1.0f));
    const glm::vec3 right = glm::normalize(glm::cross(forward, localUp));

    glm::vec3 direction(0.0f);
    if (window.IsActionActive(Action::MoveForward)) direction += forward;
    if (window.IsActionActive(Action::MoveBackward)) direction -= forward;
    if (window.IsActionActive(Action::StrafeRight)) direction += right;
    if (window.IsActionActive(Action::StrafeLeft)) direction -= right;

    if (glm::length(direction) > 0.0f) {
        direction = glm::normalize(direction);
    }
    return direction;  // normalized, or exactly zero if nothing is held
}

glm::vec3 PlayerController::ComputeSwimInputDirection(const Window& window,
                                                      const glm::vec3& localUp) const {
    // Unlike walking, swimming follows the full camera look pitch. Strafe
    // follows the yawed player frame; vertical intent follows real gravity
    // (or retained local up in zero gravity). No world-up buoyancy is used.
    const glm::quat yawedFrame = m_frameOrientation *
        glm::angleAxis(glm::radians(m_yaw), glm::vec3(0.0f, 1.0f, 0.0f));
    const glm::vec3 right = yawedFrame * glm::vec3(1.0f, 0.0f, 0.0f);
    const glm::vec3 forward = GetLookDirection();
    glm::vec3 direction(0.0f);
    if (window.IsActionActive(Action::MoveForward)) direction += forward;
    if (window.IsActionActive(Action::MoveBackward)) direction -= forward;
    if (window.IsActionActive(Action::StrafeRight)) direction += right;
    if (window.IsActionActive(Action::StrafeLeft)) direction -= right;
    if (window.IsActionActive(Action::MoveUp) || m_jumpRequested) direction += localUp;
    if (window.IsActionActive(Action::MoveDown)) direction -= localUp;
    const float length = glm::length(direction);
    return length > 0.0f ? direction / length : glm::vec3(0.0f);
}

void PlayerController::FixedUpdate(const Window& window, PhysicsWorld& physics,
                                    const GravityField& gravity, float fixedDeltaTime,
                                    bool inputEnabled) {
    // Presentation history: snapshot the state as of the END of the
    // PREVIOUS step, before this step changes it. This is bookkeeping for
    // rendering only — see GetPresentedPosition/Orientation — and reads
    // nothing that affects the authoritative computation below.
    m_previousPosition = m_position;
    m_previousOrientation = m_frameOrientation;

    // Milestone 10: snapshot of the velocity/ground-velocity as of the END
    // of the PREVIOUS step, captured before anything below overwrites
    // them — the acceleration/deceleration model needs "what was my own
    // tangential velocity a moment ago" (see the grounded branch below),
    // the same way `wasAscending` already needed "what was m_lastGroundVelocity
    // a moment ago" for its own, unrelated purpose.
    const glm::vec3 previousVelocity = m_velocity;
    const glm::vec3 previousGroundVelocity = m_lastGroundVelocity;

    const bool immersed = m_fluidSample.immersion > 0.0f;
    const glm::vec3 acceleration = gravity.Sample(m_position);
    // Orientation/support continue to use gravity, never net buoyant force.
    const glm::vec3 localUp = ComputeLocalUp(acceleration);
    UpdateFrameOrientation(localUp, fixedDeltaTime);

    // Support comes only from an actual geometry query, never a height or
    // distance-from-center comparison: sweep a short distance opposite
    // localUp and see what's there. See docs/ARCHITECTURE.md, "Support."
    //
    // The probe distance (kGroundProbeDistance) is deliberately generous
    // enough to keep catching the surface while standing still or walking,
    // which means a single fixed step's jump departure (kJumpSpeed *
    // fixedDeltaTime, a few centimeters) doesn't move the player outside
    // its reach — so the probe alone would immediately "catch" the very
    // next step after a jump and cancel it before any real arc happened.
    // The fix is the standard one: a hit only counts as support if the
    // player wasn't already moving away from the surface as of last
    // step's velocity — once ascending, the probe is ignored until that
    // stops being true, i.e. until gravity has actually turned the jump
    // around.
    //
    // Milestone 8: measured relative to whatever the player was STANDING
    // ON last step (m_lastGroundVelocity), not in absolute world terms.
    // A real jump's own velocity now does exactly what it always has, but
    // a moving support's carried velocity (see groundVelocity below) no
    // longer does — without this, a support accelerating upward (the
    // flying primitive ascending) made the player look "ascending" purely
    // because it was being carried, permanently disqualifying grounding
    // via this exact check the instant the support moved, even though the
    // player never launched itself anywhere. Reproduced directly: without
    // this fix, the player visibly fell off partway through the
    // primitive's very first ascent. See docs/ARCHITECTURE.md,
    // "Milestone 8" — this is the moving-support interaction the brief
    // called out as the most important technical test here.
    const bool wasAscending =
        glm::dot(m_velocity - m_lastGroundVelocity, localUp) > kAscendingVelocityEpsilon;
    ShapeSweepHit groundHit = physics.SweepPlayerShape(
        m_position, m_frameOrientation, -localUp * kGroundProbeDistance,
        /*interpolateDynamicBodyMotion=*/true,
        /*bodyMotionStart=*/0.0f, /*bodyMotionEnd=*/0.0f);
    bool isGrounded =
        !wasAscending && groundHit.hit && glm::dot(groundHit.normal, localUp) > kMinGroundDot;

    // Milestone 10: step-down. The ordinary ground probe above only reaches
    // kGroundProbeDistance (0.15m) — enough to keep catching a surface
    // while standing still or walking on it, but a genuine step-down (a
    // stair's riser height, a low ledge) is taller than that. Without this,
    // walking off such a step would make the player fall airborne for a
    // step or two before gravity brings them back down onto the lower
    // surface — a small stutter rather than "walking down naturally." Only
    // attempted as a fallback (the short probe found nothing) and only
    // while the player was actually walking a moment ago (m_lastGrounded)
    // and isn't mid-jump (wasAscending) — a genuine drop taller than
    // kMaxStepHeight still free-falls exactly as it always has. See
    // src/StepClimb.h; this reaches no further than kGroundProbeDistance's
    // own ordinary check would ever need to for a player that's still on
    // the ground, so it changes nothing about jump timing or ascent
    // detection — TryStepDown physically moves the player onto the found
    // floor, the same "operate relative to localUp, not world Y" contract
    // as every other position update in this function.
    if (!isGrounded && !wasAscending && m_lastGrounded) {
        glm::vec3 steppedDownPosition;
        glm::vec3 steppedDownNormal;
        BodyHandle steppedDownBody;
        if (TryStepDown(physics, m_position, m_frameOrientation, localUp, kMaxStepHeight,
                         kMinGroundDot, kSkinMargin, steppedDownPosition, steppedDownNormal,
                         steppedDownBody)) {
            m_position = steppedDownPosition;
            groundHit.hit = true;
            groundHit.normal = steppedDownNormal;
            // TryStepDown already places the capsule at the skin margin.
            // Keep the probe-distance bookkeeping consistent with that
            // pose so the grounded clearance settle below does not apply
            // the same margin a second time.
            groundHit.distance = kSkinMargin;
            groundHit.hitBody = steppedDownBody;
            isGrounded = true;
        }
    }
    m_lastGrounded = isGrounded;
    m_lastGroundHitBody = groundHit.hitBody;

    // Keep the capsule's measured support clearance at the skin margin on
    // every grounded step, including while walking. The move-and-slide
    // fallback below restores the margin along the contact normal only
    // after a sweep has reached contact; on curved supports that creates a
    // repeating 0-to-skin-margin radial correction as each straight
    // tangential step cuts slightly through the surface. The support probe
    // already measures travel along localUp, so correct along that same
    // physical direction using its result. This changes position only and
    // applies equally to arbitrary smooth support geometry and gravity
    // contexts; it does not assume gravity and contact normal are equal.
    if (isGrounded) {
        m_position += localUp * (kSkinMargin - groundHit.distance);
    }

    // Milestone 8: velocity of the supporting body's own material point
    // nearest the player — ordinary rigid-body point-velocity (v + omega x
    // r), so a TRANSLATING support carries the player and a ROTATING one
    // does too, not just a moving-in-a-straight-line one. Zero for static
    // geometry (every previous milestone's case) and for an ungrounded
    // step. The player's own capsule offset from this approximate point is
    // small relative to this demo's geometry, so m_position itself stands
    // in for "the contact point" rather than adding a dedicated field to
    // ShapeSweepHit for this one caller. See docs/ARCHITECTURE.md,
    // "Milestone 8" — this is deliberately a separate quantity from the
    // player's own input-driven velocity, added on top of it, never
    // conflated with it (supporting body motion != player input velocity).
    glm::vec3 groundVelocity(0.0f);
    if (isGrounded && physics.IsDynamicBody(groundHit.hitBody)) {
        // PlayerController runs after PhysicsWorld::Step. Its position is
        // still at the start of that interval, so carry the supported point
        // through the body's actual previous-to-current transform once. A
        // velocity * dt carry on top of a current-pose overlap correction
        // would count the same platform motion twice.
        const BodyTransform previousSupportTransform =
            physics.GetPreviousTransform(groundHit.hitBody);
        const BodyTransform supportTransform = physics.GetTransform(groundHit.hitBody);
        const glm::vec3 supportLocalPosition =
            glm::inverse(glm::normalize(previousSupportTransform.rotation)) *
            (m_position - previousSupportTransform.position);
        m_position = supportTransform.position + supportTransform.rotation * supportLocalPosition;

        const glm::vec3 supportLinearVelocity = physics.GetLinearVelocity(groundHit.hitBody);
        const glm::vec3 supportAngularVelocity = physics.GetAngularVelocity(groundHit.hitBody);
        groundVelocity = supportLinearVelocity +
                          glm::cross(supportAngularVelocity, m_position - supportTransform.position);
    }
    m_lastGroundVelocity = groundVelocity;

    // Dynamic support motion has already been applied through its transform
    // above. `groundVelocity` remains the moving-frame component of the
    // player's velocity and is subtracted from the later sweep, leaving only
    // player-relative movement to resolve against the current body pose.

    // A jump only ever begins while actually supported, per this step's own
    // geometry query — never a height comparison. Once consumed, the
    // request is cleared unconditionally below: a jump attempt made while
    // airborne is discarded, not buffered until landing (and so is one made
    // while `inputEnabled` is false — see FixedUpdate's own doc comment).
    // `jumpedThisStep` (Milestone 10) is read below to skip the step-up
    // attempt on a step that's actually a jump launch — see there.
    bool jumpedThisStep = false;
    if (isGrounded) {
        // Milestone 10: smooth acceleration/deceleration, replacing the old
        // instant "snap to desired tangential velocity" — see the
        // kGroundAcceleration/kGroundDeceleration constants' own comment
        // for the reasoning. `previousTangentVelocity` is the player's OWN
        // velocity (i.e. relative to whatever it was standing on) as of
        // the end of the previous step — deliberately excludes
        // `previousGroundVelocity` (last step's moving-support carry) so a
        // support's own motion is never treated as something the player
        // needs to "decelerate out of"; standing still on a fast-moving
        // support still reads as zero input-driven velocity, exactly as
        // before this milestone.
        const glm::vec3 previousRelativeVelocity = previousVelocity - previousGroundVelocity;
        const glm::vec3 previousTangentVelocity =
            previousRelativeVelocity - localUp * glm::dot(previousRelativeVelocity, localUp);

        const glm::vec3 desiredDirection =
            inputEnabled ? ComputeInputDirection(window, localUp) : glm::vec3(0.0f);
        const glm::vec3 desiredTangentVelocity = desiredDirection * kMoveSpeed;

        const glm::vec3 velocityDelta = desiredTangentVelocity - previousTangentVelocity;
        const float deltaLength = glm::length(velocityDelta);
        // Deceleration (the higher-magnitude, snappier rate) applies
        // whenever there's no input, OR the input direction actively
        // opposes the player's own current motion (a deliberate direction
        // reversal — see the constants' own comment); acceleration
        // otherwise (speeding up toward, or continuing in roughly, the
        // same direction already being moved in).
        const bool hasInput = glm::length(desiredDirection) > 1.0e-6f;
        const bool reversing = hasInput && glm::dot(previousTangentVelocity, desiredDirection) < 0.0f;
        const float accelerationRate =
            (!hasInput || reversing) ? kGroundDeceleration : kGroundAcceleration;
        float maxDelta = accelerationRate * fixedDeltaTime;
        if (immersed) maxDelta *= 1.0f - m_fluidSample.immersion;

        const glm::vec3 newTangentVelocity = deltaLength <= maxDelta
                                                  ? desiredTangentVelocity
                                                  : previousTangentVelocity +
                                                        (velocityDelta / deltaLength) * maxDelta;

        // Vertical speed is held at (near) zero plus the same small
        // per-step gravity nudge that's always been here (what keeps the
        // player glued to a curved surface between steps — see
        // "Locomotion," "Contact normal correctness"); a jump overrides it
        // outright — unchanged since Milestone 4/7-B, jumping stays
        // instant, only ordinary ground movement is now smoothed.
        // `groundVelocity` (zero on ordinary static ground) is added on
        // top either way, so standing still on a moving support still
        // means moving with it, and jumping from one launches relative to
        // it rather than replacing its motion.
        float verticalSpeed = glm::dot(acceleration, localUp) * fixedDeltaTime;
        if (inputEnabled && m_jumpRequested) {
            verticalSpeed = immersed
                ? verticalSpeed * m_fluidSample.immersion + kJumpSpeed * (1.0f - m_fluidSample.immersion)
                : kJumpSpeed;
            jumpedThisStep = true;
        }
        m_velocity = newTangentVelocity + localUp * verticalSpeed + groundVelocity;
    } else {
        // Airborne: ordinary integration of the FULL velocity vector —
        // not just its component along localUp. Milestone 7-B, "Velocity
        // continuity": once effective gravity can rotate substantially
        // while airborne (a gravity-context transition crossed mid-flight
        // — the entire point of that milestone), recomputing "horizontal"
        // velocity fresh from current WASD input every step (as the
        // grounded branch correctly does) would silently discard whatever
        // part of the player's existing momentum had become "tangential"
        // to gravity's new direction — exactly the kind of arbitrary
        // velocity destruction the brief forbids. Every previous milestone's
        // gravity direction changed slowly enough in the air (a normal
        // jump's brief arc) that this was never visible. See
        // docs/ARCHITECTURE.md, "Velocity continuity."
        m_velocity += acceleration * fixedDeltaTime;

        // Milestone 10: modest air control, added ON TOP of the existing
        // momentum above — never a replacement, never a reconstruction
        // from scratch (see kAirAcceleration's own comment). Only ever
        // pushes the TANGENTIAL (perpendicular to localUp) component of
        // velocity up to kMoveSpeed in the current input direction; a
        // component already exceeding that (e.g. a fast jump-and-coast
        // still carrying real speed) is left completely alone.
        if (inputEnabled) {
            const glm::vec3 desiredDirection = ComputeInputDirection(window, localUp);
            if (glm::length(desiredDirection) > 1.0e-6f) {
                const glm::vec3 tangentVelocity = m_velocity - localUp * glm::dot(m_velocity, localUp);
                const float speedInDesiredDirection = glm::dot(tangentVelocity, desiredDirection);
                if (speedInDesiredDirection < kMoveSpeed) {
                    float airDelta = kAirAcceleration * fixedDeltaTime;
                    if (immersed) airDelta *= 1.0f - m_fluidSample.immersion;
                    const float accelAmount = std::min(airDelta, kMoveSpeed - speedInDesiredDirection);
                    m_velocity += desiredDirection * accelAmount;
                }
            }
        }
    }
    if (immersed) {
        const float immersion = m_fluidSample.immersion;
        const glm::vec3 buoyancy = -(m_fluidSample.density / m_density) * immersion *
                                  (acceleration - m_fluidSample.acceleration);
        const glm::vec3 propulsion = inputEnabled
            ? ComputeSwimInputDirection(window, localUp) * (m_swimAcceleration * immersion)
            : glm::vec3(0.0f);
        m_velocity += (buoyancy + propulsion) * fixedDeltaTime;
        // Exact integration of linear relative-velocity drag over this step.
        // This is dissipative with respect to the sampled liquid velocity;
        // it cannot overshoot that velocity even at a large configured rate.
        const float relaxation = std::exp(-m_fluidDrag * immersion * fixedDeltaTime);
        m_velocity = m_fluidSample.velocity + (m_velocity - m_fluidSample.velocity) * relaxation;
    }
    m_jumpRequested = false;

    // Judas's own minimal move-and-slide: never trust a raw transform
    // write, always resolve displacement against the physics engine's
    // collision query. `groundVelocity` is subtracted back out here — the
    // support's positional motion was already applied directly above,
    // once, through its previous-to-current transform; only the player's OWN
    // relative motion (WASD, jump,
    // gravity's small glue nudge, or ordinary airborne integration) is
    // resolved through the sweep. On ordinary static ground or while
    // airborne, groundVelocity is exactly zero, so this is unchanged from
    // every milestone before this one.
    glm::vec3 remaining = (m_velocity - groundVelocity) * fixedDeltaTime;
    float bodyMotionTime = 0.0f;

    // Milestone 10: step-up, tried once with the FULL remaining
    // displacement before ordinary move-and-slide runs at all. Only
    // attempted while grounded (stepping is a walking concept, not
    // something that should intercept a jump's own launch or any airborne
    // movement) and not on the very step a jump is launched (a jump's own
    // upward velocity component would otherwise feed into the same
    // sweeps and could be misread as "stepping"). See src/StepClimb.h for
    // the actual up/forward/down sweep sequence — this function returns
    // false (leaving `remaining` and `m_position` untouched) for ordinary
    // flat ground, slopes (handled entirely by the unchanged move-and-slide
    // loop below), and anything taller than kMaxStepHeight, so this is a
    // pure addition with no effect on any pre-existing movement case.
    if (isGrounded && !jumpedThisStep) {
        glm::vec3 steppedPosition;
        if (TryStepMove(physics, m_position, m_frameOrientation, localUp, remaining, kMaxStepHeight,
                         kMinGroundDot, kSkinMargin, steppedPosition)) {
            m_position = steppedPosition;
            remaining = glm::vec3(0.0f);
        }
    }

    for (int i = 0; i < kMaxSlideIterations; ++i) {
        const float remainingLength = glm::length(remaining);
        if (remainingLength < 1.0e-6f) break;

        const ShapeSweepHit hit =
            physics.SweepPlayerShape(m_position, m_frameOrientation, remaining, !isGrounded,
                                     bodyMotionTime, 1.0f);
        if (!hit.hit) {
            m_position += remaining;
            break;
        }

        // Milestone 7-A: the player itself is not a physics-engine body
        // (see the class comment), so contact with a dynamic test object
        // would otherwise never push it — SweepPlayerShape is a read-only
        // query, not something the contact solver resolves. This is the
        // smallest correction that closes that gap: when a move sweep
        // meets a dynamic body, seed its velocity with the player's own
        // speed into it (only ever increasing that component, never
        // slowing the object down or overwriting motion along other axes)
        // and let the physics engine take over from there via the next
        // fixed step. Static world geometry is unaffected.
        if (physics.IsDynamicBody(hit.hitBody)) {
            const glm::vec3 pushDirection = -hit.normal;
            const float playerSpeedIntoObject = glm::dot(m_velocity, pushDirection);
            if (playerSpeedIntoObject > 0.0f) {
                const glm::vec3 objectVelocity = physics.GetLinearVelocity(hit.hitBody);
                const float objectSpeedIntoObject = glm::dot(objectVelocity, pushDirection);
                if (playerSpeedIntoObject > objectSpeedIntoObject) {
                    physics.SetLinearVelocity(hit.hitBody, objectVelocity + pushDirection *
                                                      (playerSpeedIntoObject - objectSpeedIntoObject));
                }
            }
        }

        // Ordinarily, travel toward the hit up to just short of it (the
        // skin margin). But a grounded step's own small inward gravity
        // nudge (see the vertical-speed integration above) continually
        // pushes the capsule a hair closer to whatever it's walking on —
        // over many steps that erodes the skin margin entirely, down to
        // hit.distance == 0 (shapes already touching). The previous
        // version of this code clamped travelDistance at a floor of zero
        // in that case and did nothing further, which — combined with an
        // unreliable contact normal specifically in the already-touching
        // case (see SweepPlayerShape's normal computation) — could leave
        // the capsule stuck at exactly zero clearance indefinitely, no
        // longer making any forward progress at all. Restoring the margin
        // directly (moving back out along the now-reliable normal) instead
        // of merely refusing to move closer keeps clearance in a small
        // band near kSkinMargin instead of letting it erode to zero. See
        // docs/ARCHITECTURE.md, "Remaining limitations" (Milestone 7-A).
        float travelFraction = 0.0f;
        if (hit.distance < kSkinMargin) {
            m_position += hit.normal * (kSkinMargin - hit.distance);
        } else {
            const float travelDistance = hit.distance - kSkinMargin;
            travelFraction = travelDistance / remainingLength;
            m_position += remaining * travelFraction;
        }
        bodyMotionTime += (1.0f - bodyMotionTime) * travelFraction;

        glm::vec3 leftover = remaining * (1.0f - travelFraction);
        const float intoSurface = glm::dot(leftover, hit.normal);
        if (intoSurface < 0.0f) {
            leftover -= hit.normal * intoSurface;
        }
        remaining = leftover;
    }
}

void PlayerController::FixedUpdateAttached(const glm::vec3& newPosition,
                                            const glm::quat& newOrientation) {
    m_fluidSample = PlayerFluidSample{};
    // Presentation history: identical bookkeeping to the start of
    // FixedUpdate — snapshot the state as of the end of the PREVIOUS step
    // before this step overwrites it.
    m_previousPosition = m_position;
    m_previousOrientation = m_frameOrientation;

    m_position = newPosition;
    m_frameOrientation = glm::normalize(newOrientation);

    // No independent locomotion happens while attached — see this
    // function's own header comment. Zeroing support/ground-carry state
    // (rather than leaving whatever they last held) means the very first
    // ordinary FixedUpdate call after release starts from a clean,
    // unambiguous "not grounded, no support" state and runs its own real
    // geometry probe, exactly like any other newly-airborne player —
    // never a stale support reference to an object the player is no
    // longer physically touching.
    m_velocity = glm::vec3(0.0f);
    m_lastGrounded = false;
    m_lastGroundHitBody = BodyHandle();
    m_lastGroundVelocity = glm::vec3(0.0f);
    // A jump press during piloting is discarded, not buffered until
    // release — mirrors FixedUpdate's own "airborne/disabled input is
    // never buffered" rule for m_jumpRequested.
    m_jumpRequested = false;
}

void PlayerController::Reset() {
    m_fluidSample = PlayerFluidSample{};
    m_position = m_spawnPosition;
    m_velocity = glm::vec3(0.0f);
    m_frameOrientation = glm::quat(1.0f, 0.0f, 0.0f, 0.0f);
    m_lastGrounded = false;
    m_lastGroundHitBody = BodyHandle();
    m_lastGroundVelocity = glm::vec3(0.0f);
    // Synchronize presentation history to the same pose: with both
    // endpoints identical, GetPresentedPosition/Orientation return exactly
    // the reset pose regardless of `alpha`, so the very next render
    // presents the reset position directly — never an interpolation
    // across the world from wherever the player was. See
    // docs/ARCHITECTURE.md, "Reset and discontinuities."
    m_previousPosition = m_position;
    m_previousOrientation = m_frameOrientation;
    m_yaw = m_spawnYawDegrees;
    m_pitch = 0.0f;
    m_jumpRequested = false;
}

glm::vec3 PlayerController::GetPresentedPosition(float alpha) const {
    return glm::mix(m_previousPosition, m_position, std::clamp(alpha, 0.0f, 1.0f));
}

glm::quat PlayerController::GetPresentedOrientation(float alpha) const {
    return glm::slerp(m_previousOrientation, m_frameOrientation, std::clamp(alpha, 0.0f, 1.0f));
}

glm::vec3 PlayerController::GetLookDirection() const {
    const glm::quat lookOrientation =
        m_frameOrientation * glm::angleAxis(glm::radians(m_yaw), glm::vec3(0.0f, 1.0f, 0.0f)) *
        glm::angleAxis(glm::radians(m_pitch), glm::vec3(1.0f, 0.0f, 0.0f));
    return glm::normalize(lookOrientation * glm::vec3(0.0f, 0.0f, -1.0f));
}

void PlayerController::GetTorchTransform(float presentationAlpha, glm::vec3& outPosition,
                                          glm::vec3& outDirection) const {
    // The actual geometry is a pure function of (presented pose, free-look
    // yaw/pitch, eye height) — factored into src/LightTransforms.h so it's
    // directly unit-testable with hand-crafted (including rotated) poses
    // without needing a real PlayerController driven through gravity/input
    // — see tests/LightingTests.cpp.
    ComputeTorchTransform(GetPresentedPosition(presentationAlpha), GetPresentedOrientation(presentationAlpha),
                          m_yaw, m_pitch, kEyeHeightAboveCenter, outPosition, outDirection);
}

glm::mat4 PlayerController::BuildViewMatrix(const glm::vec3& position,
                                             const glm::quat& orientation,
                                             PlayerViewMode mode) const {
    // Mouse look remains on top of the interpolated player frame and updates
    // every render frame. Only the camera offset changes between modes.
    const PlayerCameraPose pose = ComputePlayerCameraPose(
        position, orientation, m_yaw, m_pitch, mode, kEyeHeightAboveCenter,
        kCameraFollowDistance, kCameraHeightOffset);
    return glm::lookAt(pose.position, pose.position + pose.front, pose.up);
}

glm::mat4 PlayerController::GetViewMatrix(float presentationAlpha, PlayerViewMode mode) const {
    return BuildViewMatrix(GetPresentedPosition(presentationAlpha),
                            GetPresentedOrientation(presentationAlpha), mode);
}

glm::mat4 PlayerController::GetViewMatrix(const glm::vec3& anchorPosition,
                                           const glm::quat& anchorOrientation) const {
    return BuildViewMatrix(anchorPosition, anchorOrientation);
}

glm::mat4 PlayerController::GetProjectionMatrix(float aspectRatio) const {
    return glm::perspective(glm::radians(kFovDegrees), aspectRatio, kNearPlane, kFarPlane);
}

glm::vec3 PlayerController::GetRenderHalfExtents() const {
    return glm::vec3(kCapsuleRadius, kCapsuleHalfHeight + kCapsuleRadius, kCapsuleRadius);
}

float PlayerController::CapsuleRadius() { return kCapsuleRadius; }
float PlayerController::CapsuleHalfHeight() { return kCapsuleHalfHeight; }
