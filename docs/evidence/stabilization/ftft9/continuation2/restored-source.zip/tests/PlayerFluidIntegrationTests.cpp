// FTFT9 actual particle-field -> ordinary played-world -> custom-player tests.
// No SetFluidSample calls, alternate fluid loop, or particle-force injection.
#include <algorithm>
#include <chrono>
#include <cmath>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <glm/gtc/quaternion.hpp>
#include "GameSession.h"
#include "ProductionFluidCoupling.h"
#include "RuntimeWorld.h"
#include "SceneSerialization.h"
#include "Simulation.h"
#include "SimulationTiming.h"
#include "Window.h"
namespace {
namespace fs=std::filesystem;int checks=0,failures=0,diagnosticChecks=0,diagnosticFailures=0,steps=0,poolWarmupSteps=240;float particleUpdateRate=30;constexpr float dt=SimulationTiming::kFixedTimestep;
void Check(bool value,const std::string& label){++checks;failures+=!value;if(!value)std::cerr<<"FAIL "<<label<<'\n';}
void StrictMicroRestDiagnostic(bool value,const std::string& label){++diagnosticChecks;diagnosticFailures+=!value;if(!value)std::cerr<<"STRICT_MICROREST_FAILURE "<<label<<'\n';}
struct Frame {glm::quat q{1,0,0,0};glm::vec3 offset{0};glm::vec3 Point(glm::vec3 p)const{return offset+q*p;}};
struct Result{std::string name;int count=0,failures=0;float density=0,spacing=0,maxSpeed=0,maxImmersion=0,minImmersion=1,finalImmersion=0,relativeDrift=0,synchronizedRelativeDrift=0,independentFallError=0,warmupMeanSpeed=0,warmupBulkSpeed=0,warmupCentroidTravel=0,finalMeanParticleSpeed=0,jumpImmersion=0,jumpDeltaSpeed=0;int warmupSteps=0;glm::vec3 initial{0},final{0},velocity{0};double seconds=0,maxParticleMs=0;unsigned long long particleSteps=0;};
std::vector<Result> results;
void Box(Scene& s,const Frame& frame,glm::vec3 p,glm::vec3 h){auto&o=s.CreateObject("Boundary");o.transform.position=frame.Point(p);o.transform.rotation=frame.q;o.body=SceneBodyComponent{};o.body->halfExtents=h;}
Scene Fixture(const Frame& frame,float spacing,float density,bool pool,float gravity,glm::vec3 player){Scene s;s.Settings().name="FTFT9 particle-field player";s.Settings().fluidScale=spacing/.05f;s.Settings().fluidUpdateRateHz=particleUpdateRate;
// One deep reference pool for every density: full capsule immersion and
// clearance from the bottom must both be possible after the PBF lattice settles.
if(pool){Box(s,frame,{0,-.2f,0},{1.3f,.2f,1.3f});Box(s,frame,{-1.3f,3,0},{.2f,3,1.5f});Box(s,frame,{1.3f,3,0},{.2f,3,1.5f});Box(s,frame,{0,3,-1.3f},{1.5f,3,.2f});Box(s,frame,{0,3,1.3f},{1.5f,3,.2f});}
auto& f=s.CreateObject("Liquid volume");f.transform.position=frame.Point({0,spacing*.5f,0});f.transform.rotation=frame.q;f.fluidVolume=SceneFluidVolumeComponent{};f.fluidVolume->spacing=spacing;f.fluidVolume->countX=int(std::lround((pool?2.f:3.f)/spacing));f.fluidVolume->countY=int(std::lround((pool?5.f:3.f)/spacing));f.fluidVolume->countZ=int(std::lround(2/spacing));
auto& g=s.CreateObject("Gravity region");g.transform.position=frame.offset;g.transform.rotation=frame.q;g.gravity=SceneGravityComponent{};g.gravity->kind=SceneGravityKind::Uniform;g.gravity->magnitude=gravity;g.gravity->regionRadius=100;
auto& p=s.CreateObject("Player start");p.transform.position=frame.Point(player);p.playerStart=ScenePlayerStartComponent{};p.playerStart->density=density;p.playerStart->fluidDrag=2;p.playerStart->swimAcceleration=4;return s;}
struct Played{RuntimeWorld world;GameSession session;Window window;bool Begin(const Scene& scene,const fs::path& out,const std::string& name){std::string text,error;bool ok=SaveSceneToString(scene,text);Check(ok,name+" serialize");if(!ok)return false;std::ofstream(out/(name+".judas"))<<text;Scene loaded;ok=LoadSceneFromString(text,loaded,error);Check(ok,name+" scene load "+error);if(!ok)return false;window.SetTestInputMode(true);ok=world.Build(loaded,nullptr,error)&&session.Begin(world,error);Check(ok,name+" runtime/session "+error);return ok;}void Step(){session.HandleFrameInput(window,false,false,false,false,false);StepPlayedWorld(session,window,dt);++steps;}};
glm::vec3 Centroid(const FluidWorld& fluid){glm::dvec3 sum(0);double mass=0;for(const auto&p:fluid.Particles()){sum+=glm::dvec3(p.position)*double(p.mass);mass+=p.mass;}return mass>0?glm::vec3(sum/mass):glm::vec3(0);}
bool Finite(glm::vec3 v){return std::isfinite(v.x)&&std::isfinite(v.y)&&std::isfinite(v.z);}
Result Run(const fs::path& out,const std::string& family,const Frame& frame,float spacing,float density,bool pool,float gravity,glm::vec3 spawn,int count,bool swim=false){Result r;r.name=family+"-"+std::to_string(int(spacing*100))+"-"+std::to_string(int(density));r.spacing=spacing;r.density=density;const int beforeFailures=failures;const auto begin=std::chrono::steady_clock::now();Played p;if(!p.Begin(Fixture(frame,spacing,density,pool,gravity,pool?glm::vec3(20,1.5f,0):spawn),out,r.name))return r;
Check(p.session.Player().Density()==density&&p.session.Player().FluidDrag()==2&&p.session.Player().SwimAcceleration()==4,r.name+" serialized player settings reach controller");Check(p.world.DynamicBodies().empty(),r.name+" player is not a rigid participant");
Played reference;if(swim&&!reference.Begin(Fixture(frame,spacing,density,pool,gravity,{20,1.5f,0}),out,r.name+"-particle-reference"))return r;
// Fixed ordinary-world warmup, identical for all pool densities. The player is
// distant and is then spawned through the normal release/spawn API. Raw initial
// unsettled-pool runs remain in player-integration/run1 as diagnostic evidence.
if(pool){
 r.warmupSteps=poolWarmupSteps;std::ofstream warm(out/(r.name+"-warmup.csv"));
 warm<<std::setprecision(17)<<"step,centroid_x,centroid_y,centroid_z,mean_particle_speed,bulk_velocity_x,bulk_velocity_y,bulk_velocity_z,last_second_centroid_travel\n";
 glm::vec3 referenceCentroid(0);const int observationFrames=int(std::lround(1.0/dt));
 for(int i=0;i<r.warmupSteps;++i){
  p.Step();double speed=0,mass=0;glm::dvec3 momentum(0);
  for(const auto& particle:p.world.Fluid().Particles()){speed+=glm::length(particle.velocity);mass+=particle.mass;momentum+=double(particle.mass)*glm::dvec3(particle.velocity);}
  r.warmupMeanSpeed=float(speed/p.world.Fluid().Particles().size());
  const glm::vec3 bulk=glm::vec3(momentum/mass);r.warmupBulkSpeed=glm::length(bulk);const auto c=Centroid(p.world.Fluid());
  if(i==r.warmupSteps-observationFrames-1)referenceCentroid=c;
  if(i>=r.warmupSteps-observationFrames)r.warmupCentroidTravel=std::max(r.warmupCentroidTravel,glm::length(c-referenceCentroid));
  warm<<i<<','<<c.x<<','<<c.y<<','<<c.z<<','<<r.warmupMeanSpeed<<','<<bulk.x<<','<<bulk.y<<','<<bulk.z<<','<<r.warmupCentroidTravel<<'\n';
 }
 // Passive exact particle snapshot for independent field/settling diagnosis.
 std::ofstream particles(out/(r.name+"-warmup-particles.csv"));particles<<std::setprecision(17)<<"id,mass,x,y,z,vx,vy,vz,ax,ay,az\n";
 std::size_t index=0;for(const auto& particle:p.world.Fluid().Particles())particles<<index++<<','<<particle.mass<<','<<particle.position.x<<','<<particle.position.y<<','<<particle.position.z<<','<<particle.velocity.x<<','<<particle.velocity.y<<','<<particle.velocity.z<<','<<particle.acceleration.x<<','<<particle.acceleration.y<<','<<particle.acceleration.z<<'\n';
 const auto& fluidSettings=p.world.Fluid().Settings();std::ofstream(out/(r.name+"-fluid-settings.json"))<<std::setprecision(17)<<"{\"rest_density\":"<<fluidSettings.restDensity<<",\"particle_radius\":"<<fluidSettings.particleRadius<<",\"smoothing_radius\":"<<fluidSettings.smoothingRadius<<",\"substeps\":"<<fluidSettings.substeps<<",\"density_iterations\":"<<fluidSettings.densityIterations<<",\"maximum_density_correction\":"<<fluidSettings.maxDensityCorrection<<",\"velocity_smoothing\":"<<fluidSettings.velocitySmoothing<<"}\n";
 // The original micro-rest prerequisite remains a hard acceptance assertion.
 // Bulk observations are additive and cannot replace or soften this gate.
 Check(r.warmupMeanSpeed<.05f,r.name+" fixed reference-pool warmup is quiescent");
 StrictMicroRestDiagnostic(r.warmupMeanSpeed<.05f,r.name+" unchanged mean-particle-speed <0.05 m/s prerequisite");
 // Additional first-moment observations of macroscopic pool stationarity.
 Check(r.warmupBulkSpeed<.05f,r.name+" reference-pool mass-weighted bulk speed <0.05 m/s");
 Check(r.warmupCentroidTravel<.05f,r.name+" reference-pool centroid travel <0.05 m over last second");
 p.session.Player().SetPositionAfterRelease(Centroid(p.world.Fluid()));p.session.Player().SetVelocityAfterRelease(glm::vec3(0));
}
const auto priorParticleSteps=p.world.FluidCoupling().Measurements().executedSteps;
r.initial=p.session.Player().GetPosition();const auto initialRelative=r.initial-Centroid(p.world.Fluid());const std::size_t initialParticles=p.world.Fluid().Particles().size();std::ofstream csv(out/(r.name+".csv"));csv<<std::setprecision(17)<<"step,x,y,z,vx,vy,vz,immersion,fluid_vx,fluid_vy,fluid_vz,fluid_ax,fluid_ay,fluid_az,fluid_executed,particle_ms\n";bool entered=false,left=false;float entryZ=0;bool compared=false;
for(int i=0;i<count;++i){const auto beforeVelocity=p.session.Player().GetVelocity();if(swim){p.window.SetTestActionState(Action::MoveForward,true);if(i==120)p.window.RequestTestJump();reference.Step();}p.Step();const auto&player=p.session.Player();const auto state=player.GetFluidSample();const auto position=player.GetPosition(),v=player.GetVelocity();const auto&measured=p.world.FluidCoupling().Measurements();
Check(Finite(position)&&Finite(v)&&state.immersion>=0&&state.immersion<=1,r.name+" finite bounded actual field/controller state");Check(p.world.Fluid().Particles().size()==initialParticles,r.name+" finite particle inventory preserved");r.maxSpeed=std::max(r.maxSpeed,glm::length(v));r.maxImmersion=std::max(r.maxImmersion,state.immersion);r.minImmersion=std::min(r.minImmersion,state.immersion);r.maxParticleMs=std::max(r.maxParticleMs,measured.particleMilliseconds);if(measured.executed)r.synchronizedRelativeDrift=glm::length((position-Centroid(p.world.Fluid()))-initialRelative);
if(swim&&i==120){r.jumpImmersion=state.immersion;r.jumpDeltaSpeed=glm::dot(v-beforeVelocity,frame.q*glm::vec3(0,1,0));Check(r.jumpImmersion>.2f,r.name+" real jump input occurs while immersed");Check(r.jumpDeltaSpeed>0&&r.jumpDeltaSpeed<=4*dt+1e-4f,r.name+" actual-field jump gives positive bounded swim acceleration");}
if(swim){if(!entered&&state.immersion>.2f){entered=true;entryZ=position.z;}if(entered&&state.immersion==0&&position.z<entryZ-1)left=true;}
csv<<i<<','<<position.x<<','<<position.y<<','<<position.z<<','<<v.x<<','<<v.y<<','<<v.z<<','<<state.immersion<<','<<state.velocity.x<<','<<state.velocity.y<<','<<state.velocity.z<<','<<state.acceleration.x<<','<<state.acceleration.y<<','<<state.acceleration.z<<','<<measured.executed<<','<<measured.particleMilliseconds<<'\n';}
if(pool){double speed=0;for(const auto& particle:p.world.Fluid().Particles())speed+=glm::length(particle.velocity);r.finalMeanParticleSpeed=float(speed/p.world.Fluid().Particles().size());}
r.final=p.session.Player().GetPosition();r.velocity=p.session.Player().GetVelocity();r.finalImmersion=p.session.Player().GetFluidSample().immersion;r.particleSteps=p.world.FluidCoupling().Measurements().executedSteps-priorParticleSteps;r.count=count;
const auto finalRelative=r.final-Centroid(p.world.Fluid());r.relativeDrift=glm::length(finalRelative-initialRelative);
Check(r.particleSteps>0&&r.particleSteps<static_cast<unsigned long long>(count),r.name+" real particle solver runs at reduced cadence");const float speedBound=(!pool&&gravity>0)?gravity*dt*count+1.f:12.f;Check(r.maxSpeed<speedBound,r.name+" no explosive player response beyond ordinary gravity/input budget");
const float rise=glm::dot(r.final-r.initial,frame.q*glm::vec3(0,1,0));
if(family=="density"||family=="rotated-density"){Check(r.maxImmersion>.8f,r.name+" player starts substantially inside actual coarse fluid");if(density<1000)Check(rise>.4f,r.name+" low density player rises");else if(density==1000)Check(std::abs(rise)<.25f,r.name+" neutral player has no rapid systematic drift");else Check(rise<-.35f,r.name+" dense player sinks toward physical floor");}
if(family=="common-fall"||family=="rotated-fall"){Check(r.synchronizedRelativeDrift<.2f,r.name+" common free fall at matching executed-fluid timestamp avoids large artificial relative motion");const glm::dvec3 expected=glm::dvec3(r.initial)+glm::dvec3(frame.q*glm::vec3(0,-gravity,0))*(double(dt)*double(dt)*double(count)*double(count+1)*.5);r.independentFallError=float(glm::length(glm::dvec3(r.final)-expected));Check(r.independentFallError<.05f,r.name+" independent semi-implicit constant-gravity endpoint");}
if(family=="zero-g"){Check(r.maxImmersion>.5f,r.name+" zero-gravity player actually samples liquid");Check(glm::length(r.final-r.initial)<.1f&&glm::length(r.velocity)<.05f,r.name+" quiescent zero gravity invents no buoyancy");}
if(swim){Check(entered&&left&&r.finalImmersion==0,r.name+" input enters, swims through and leaves real coarse particle field");Check(r.final.z<r.initial.z-5,r.name+" no coarse-particle column stall");const auto&a=p.world.Fluid().Particles();const auto&b=reference.world.Fluid().Particles();bool equal=a.size()==b.size();if(equal)for(std::size_t i=0;i<a.size();++i)equal&=a[i].position==b[i].position&&a[i].velocity==b[i].velocity&&a[i].acceleration==b[i].acceleration;compared=equal;Check(equal,r.name+" moving player adds no particle contact/push: exact reference particle trajectory");}
r.seconds=std::chrono::duration<double>(std::chrono::steady_clock::now()-begin).count();r.failures=failures-beforeFailures;std::cout<<std::setprecision(9)<<"CASE "<<r.name<<" failures="<<r.failures<<" height_change="<<rise<<" final_immersion="<<r.finalImmersion<<" max_speed="<<r.maxSpeed<<" relative_drift="<<r.relativeDrift<<" synchronized_relative_drift="<<r.synchronizedRelativeDrift<<" independent_fall_error="<<r.independentFallError<<" warmup_steps="<<r.warmupSteps<<" warmup_mean_speed="<<r.warmupMeanSpeed<<" warmup_bulk_speed="<<r.warmupBulkSpeed<<" warmup_centroid_travel="<<r.warmupCentroidTravel<<" final_mean_particle_speed="<<r.finalMeanParticleSpeed<<" jump_immersion="<<r.jumpImmersion<<" jump_delta_speed="<<r.jumpDeltaSpeed<<" particle_steps="<<r.particleSteps<<" seconds="<<r.seconds<<" particle_reference_equal="<<compared<<'\n';return r;}
}
int main(int argc,char**argv){fs::path output;bool smoke=false;float smokeSpacing=.25f;for(int i=1;i<argc;++i){if(std::string(argv[i])=="--output"&&i+1<argc)output=argv[++i];else if(std::string(argv[i])=="--smoke")smoke=true;else if(std::string(argv[i])=="--smoke-spacing"&&i+1<argc)smokeSpacing=std::stof(argv[++i]);else if(std::string(argv[i])=="--warmup-steps"&&i+1<argc)poolWarmupSteps=std::stoi(argv[++i]);else if(std::string(argv[i])=="--fluid-rate"&&i+1<argc)particleUpdateRate=std::stof(argv[++i]);else return 2;}if(output.empty())output=fs::temp_directory_path()/("judas-ftft9-player-"+std::to_string(std::chrono::steady_clock::now().time_since_epoch().count()));if(fs::exists(output)&&!fs::is_empty(output)){std::cerr<<"Refusing to overwrite evidence\n";return 2;}fs::create_directories(output);const Frame identity{};const Frame rotated{glm::angleAxis(.83f,glm::normalize(glm::vec3(1,-2,3))),{3,-2,4}};
for(float spacing:smoke?std::vector<float>{smokeSpacing}:std::vector<float>{.2f,.25f})for(float density:smoke?std::vector<float>{1000.f}:std::vector<float>{500.f,1000.f,2000.f})results.push_back(Run(output,"density",identity,spacing,density,true,9.81f,{0,1.5f,0},240));
if(!smoke){results.push_back(Run(output,"rotated-density",rotated,.25f,500,true,9.81f,{0,1.5f,0},240));results.push_back(Run(output,"common-fall",identity,.25f,1000,false,9.81f,{0,1.5f,0},120));results.push_back(Run(output,"rotated-fall",rotated,.25f,1000,false,9.81f,{0,1.5f,0},120));results.push_back(Run(output,"zero-g",identity,.25f,500,false,0,{0,1.5f,0},240));for(float spacing:{.2f,.25f})results.push_back(Run(output,"swim-through",identity,spacing,950,false,0,{0,1.5f,4},300,true));}
std::ostringstream out;out<<std::setprecision(17)<<"{\"checks\":"<<checks<<",\"failures\":"<<failures<<",\"strict_microrest_checks\":"<<diagnosticChecks<<",\"strict_microrest_failures\":"<<diagnosticFailures<<",\"strict_microrest_pass\":"<<(diagnosticFailures?"false":"true")<<",\"ordinary_steps\":"<<steps<<",\"pass\":"<<(failures?"false":"true")<<",\"fixtures\":[";for(std::size_t i=0;i<results.size();++i){if(i)out<<',';const auto&r=results[i];out<<"{\"name\":\""<<r.name<<"\",\"steps\":"<<r.count<<",\"failures\":"<<r.failures<<",\"spacing\":"<<r.spacing<<",\"density\":"<<r.density<<",\"initial_position\":["<<r.initial.x<<','<<r.initial.y<<','<<r.initial.z<<"],\"final_position\":["<<r.final.x<<','<<r.final.y<<','<<r.final.z<<"],\"final_velocity\":["<<r.velocity.x<<','<<r.velocity.y<<','<<r.velocity.z<<"],\"final_immersion\":"<<r.finalImmersion<<",\"maximum_immersion\":"<<r.maxImmersion<<",\"max_speed\":"<<r.maxSpeed<<",\"relative_drift\":"<<r.relativeDrift<<",\"synchronized_relative_drift\":"<<r.synchronizedRelativeDrift<<",\"independent_fall_error\":"<<r.independentFallError<<",\"warmup_steps\":"<<r.warmupSteps<<",\"warmup_mean_speed\":"<<r.warmupMeanSpeed<<",\"warmup_bulk_speed\":"<<r.warmupBulkSpeed<<",\"warmup_centroid_travel\":"<<r.warmupCentroidTravel<<",\"final_mean_particle_speed\":"<<r.finalMeanParticleSpeed<<",\"jump_immersion\":"<<r.jumpImmersion<<",\"jump_delta_speed\":"<<r.jumpDeltaSpeed<<",\"particle_steps\":"<<r.particleSteps<<",\"max_particle_ms\":"<<r.maxParticleMs<<",\"seconds\":"<<r.seconds<<'}';}out<<"]}\n";std::ofstream(output/"results.json")<<out.str();std::cout<<"SUMMARY checks="<<checks<<" failures="<<failures<<" strict_microrest_checks="<<diagnosticChecks<<" strict_microrest_failures="<<diagnosticFailures<<" ordinary_steps="<<steps<<'\n';return failures?1:0;}
