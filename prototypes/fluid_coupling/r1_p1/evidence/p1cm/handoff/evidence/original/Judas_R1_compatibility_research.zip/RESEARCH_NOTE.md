# Judas R1: transport compatibility research checks

## Status and scope

This is independent research, not an implementation in the Judas repository. P1-C's
reported PASS remains untouched. Nothing here establishes P1-D/E, moving-body pressure
coupling, buoyancy, swimming, or a production performance budget.

Two outcomes:

1. A precise fixed-grid mass/momentum extension to the frozen-WY symmetric sweep
   construction is available, with conservation/constant-state algebra and a small
   independent numerical implementation.
2. A moving-cut-cell remap contract is derived and checked for prescribed rigid
   co-motion. Construction of a bounded, capacity-consistent transport map for general
   relative fluid/body motion, compatible with JSGT, is NOT yet established.

The accompanying Python is newly written research-check code. It uses NumPy and
Shapely; it is not copied from Judas or from an author's implementation.

## 1. Shared mass accounting on a fine transport grid

Use a volume-fraction grid with spacing h and staggered momentum/pressure grid with
spacing 2h. This is a uniform two-level arrangement, not adaptive mesh refinement.
Every coarse staggered velocity control volume is a union of fine transport cells.

This follows the common-subgrid principle of Pal, Fuster and Zaleski [1]. Their method
is not itself JSGT and does not provide our moving-solid transport extension.

Let V_a be a fine-cell volume, C_a its liquid fraction, and rho_l,rho_g positive constant
phase densities. Define:

    m_a = V_a * (rho_g + (rho_l-rho_g)*C_a)

Let Q_f be signed total transported volume across a fine face, and Ql_f the liquid
volume from the actual geometric sweep. Use the SAME stored volumes to compute:

    Fm_f = rho_l*Ql_f + rho_g*(Q_f-Ql_f)

For a directional WY sweep with frozen c_a = 1(C_a^n > 1/2), and
D_a,d = dt*directional_divergence_a,d:

    S_a,d = V_a * (rho_g + (rho_l-rho_g)*c_a) * D_a,d
    m_a,out = m_a,in - outward_sum(Fm_f) + S_a,d

These follow algebraically from the authorized fraction update. The source cannot be
omitted in directional intermediate mass/momentum states even though it cancels over
all directions for discretely divergence-free velocities.

Mass on a staggered momentum control volume Q is a sum of fine masses. Its mass flux
is a sum of the fine fluxes on its boundary; internal fine faces cancel. There is no
independent coarse/shifted PLIC reconstruction used to redefine its mass.

For component momentum P_Q and a declared donor-cell velocity reconstruction:

    Fp_f = Fm_f * u_advected,f
    P_Q,out = P_Q,in - outward_sum(Fp_f) + u_Q^n * S_Q,d

The source velocity u_Q^n is frozen over directions and both sweep orders. The velocity
used in the *advective flux* is obtained from the current directional stage. These are
different roles. This ordering is supported by [1] and independently by Eqs. 5-7 of [2].

Common-velocity proof: if P=M*U initially, each matching mass/momentum update preserves
P=M*U. Global component momentum telescopes through shared fluxes; frozen source terms
cancel when the discrete full divergence vanishes and appropriate boundary budgets
are included.

This proves consistency and global component-momentum conservation in that setting.
It does not prove general angular-momentum conservation, high-order accuracy, or a
full fluid/body energy law.

## 2. Symmetric combination: average conserved quantities

Compute both complete orders, xy and yx, using the same initial state, advecting
velocity field and frozen WY coefficient.

    M_new = 0.5*(M_xy + M_yx)
    P_new = 0.5*(P_xy + P_yx)
    u_new = P_new/M_new

Do NOT independently average velocities. For example, masses (1,9) and velocities
(1,0) imply combined mass 5, momentum 0.5 and velocity 0.1; averaging velocities gives
0.5 and incorrectly implies momentum 2.5.

Because density is affine in C and fine-to-coarse restriction is linear, the averaged
branch mass agrees with restriction from the averaged final fraction. JSGT's proven
fraction sweep identity therefore remains usable; this is our extension of it, not
a claim about the original COSMIC implementation.

For positive masses the combination itself cannot exceed the mean of the two branch
kinetic energies (convexity of P^2/(2M)). This is not a proof that either entire branch
or the subsequent pressure/body timestep is energy stable.

## 3. Moving-cut-cell conservation contract

Let A_i^n be the actual fluid-accessible area and L_i^n the liquid area. The correct
capacity bound is 0 <= L_i^n <= A_i^n, rather than only C <= 1.

For incompressible fluid and impermeable moving solids:

    A_i^(n+1) - A_i^n + sum_f(time_integrated_open_face_volume_flux_f) = 0

This is the moving-volume balance that transport must satisfy. Endpoint geometry plus
unmodified full-cell fluxes does not automatically satisfy it. Moving-boundary
literature [3,4] supports using the same space-time geometry in the conservation law.
[3] concerns compressible Euler flow and [4] concerns diffusion: neither establishes
bounded incompressible JSGT cut-cell transport.

A sufficient geometric remap construction uses donor/receiver volumes T_ji:

    T_ji >= 0
    sum_j T_ji = A_i^old
    sum_i T_ji = A_j^new

For transported liquid overlaps L_ji:

    0 <= L_ji <= T_ji
    sum_j L_ji = L_i^old
    L_j^new = sum_i L_ji

Then phase conservation and new-cell capacity bounds follow by summation. Transport
mass with the same pieces:

    m_ji = rho_l*L_ji + rho_g*(T_ji-L_ji)

Closed-boundary statements above require boundary-entry/exit terms for open domains.
Nonnegative conservative weights alone are insufficient: column sums can preserve
mass while incorrect row sums overfill some new cells.

For known volume-preserving co-motion map Phi:

    T_ji = area(Phi(old_fluid_subcell_i) intersect new_fluid_subcell_j)

This is constructive for the prescribed translations/rotations used in the checks.
For GENERAL computed fluid motion, a common non-overlapping, volume-preserving flow
map respecting moving walls still has to be constructed and connected to JSGT.
Writing this formula does not solve that construction.

The exact co-motion remap does not divide an outgoing flux by a tiny old cell area.
This alone does NOT solve general explicit cut-cell timestep restrictions or pressure
conditioning as masses approach zero.

## 4. Thin walls and reference implementations

Cut geometry must retain disconnected fluid components inside a background cell.
Azevedo et al. [5] provides a concrete topology-aware treatment, but its demonstrated
coupling is one-way and its advection is PIC/FLIP: it is NOT a ready-made JSGT/FSI
implementation.

Do not use common background-cell membership as permission to transfer fluid or
pressure through a solid wall. This is geometric connectivity, not a physical
ambient/held-water classifier.

Basilisk's VOF embedded-boundary path [6] explicitly documents an approximation that
ignores the volume occupied by solids when defining its conservation claim. It cannot
be copied as proof of the physical moving-capacity contract above.

## 5. Executed checks

Run:

    python compatibility_checks.py

The script writes compatibility_results.json.

### Fixed-grid ledger checks

24x24 fine VOF cells and 12x12 MAC cells, periodic domain, density ratios 1, 1000,
1,000,000; uniform and nonuniform divergence-free prescribed advection; constant,
smooth and random transported velocity fields. Eighteen cases, twelve timesteps each.
The script includes independent local PLIC clipping, both complete WY sweep orders,
fine-to-staggered restriction, matching momentum sources, and conserved-quantity
averaging. It never calls Judas code.

Constant transported vectors under a nonuniform prescribed advector are manufactured
transport checks, not solutions with that vector simultaneously defining the advector.
The smooth/random fields are also advection-only checks, without pressure projection.

Raw fraction excursions remain roundoff-sized. Conservation and uniform-vector errors
are in the JSON. A negative control that divides new momentum by OLD mass produces
large spurious velocities at high density ratios, showing the diagnostic detects that
specific inconsistency.

Momentum reconstruction here is first-order donor-cell. Recorded non-increasing energy
and velocity bounds on these cases are observations, not a general theorem.

### Moving geometry checks

A square tank cut by a thin wall into two disconnected fluid regions, with a sloping
liquid/gas interface. Prescribed translation and rotation, each with an ordinary cut
and a roughly 1.25e-10-area sliver. New fluid regions are clipped and overlap-remapped.

These check donor and receiver partition sums, fluid capacity, liquid volume, and no
cross-wall transfer. Total initial liquid area has an independent analytic integral.
Per-cell comparisons reuse Shapely's geometry library and are partition/metamorphic
checks, not an independent exact-arithmetic geometry oracle. Zero/dying/new cells are
represented by absence/presence of geometric pieces, not by an arbitrary density floor.

Neither these geometry tests nor the ledger tests simulate fluid force on a body.

## 6. What is ready, and what remains open

Ready to specify narrowly:
- fine-grid mass/flux ownership;
- stage-consistent staggered momentum advection;
- symmetric averaging of mass and momentum;
- uniform-velocity and conservation tests;
- geometric moving-volume and thin-wall connectivity checks.

Not yet ready to specify as a complete integrated solver:
- general moving-cut-cell JSGT phase-flux construction meeting BOTH donor-volume and
  receiver-capacity conditions;
- its small-cell stabilization and coupling across any regular/cut-cell interface;
- body-motion/geometry/projection time levels for that particular discretization;
- complete angular-momentum/energy behavior and 3D/production performance.

No additional code should be sent to the implementer under a claim that these last
items are already solved.

## Sources actually inspected

[1] Pal, Fuster, Zaleski, 'A novel momentum-conserving, mass-momentum consistent method
for interfacial flows involving large density contrasts', 2021, particularly Sections
3.2 and 3.4. https://arxiv.org/pdf/2101.04142

[2] Huang, Valle, Lidtke, Hendrickson, Weymouth, 'Sharp-interface Simulations of Energetic
Multiphase Flows with Large Density and Viscosity Ratios', 2026 preprint, particularly
Eqs. 5-8 and its explicit statement that fluid-structure coupling is future work.
https://arxiv.org/html/2606.02467v1

[3] Bennett, Nikiforakis, Klein, 'A Moving Boundary Flux Stabilization Method for
Cartesian Cut-Cell Grids using Directional Operator Splitting'.
https://arxiv.org/html/1711.11361v2

[4] Libat et al., 'A space-time extension of a conservative two-fluid cut-cell diffusion
method for moving geometries', 2025 preprint, Section 4.1.2.
https://arxiv.org/html/2512.23358v1

[5] Azevedo, Batty, Oliveira, 'Preserving Geometry and Topology for Fluid Flows with Thin
Obstacles and Narrow Gaps', 2016.
https://cs.uwaterloo.ca/~c2batty/papers/Azevedo2016.pdf

[6] Basilisk VOF implementation, embedded-boundary and frozen compression branches.
https://basilisk.fr/src/vof.h

Related sources inspected: van der Eijk & Wellens 2023/2024; Batty et al. 2007;
Robinson-Mosher et al. 2010; Grétarsson & Fedkiw 2013. These provide additional pressure,
geometry and conservative-remapping context, not a verified off-the-shelf replacement
for the currently approved JSGT method.
