# Frozen-geometry pressure/body research reference

Start with RESEARCH_NOTE.md for the method, results and limitations.

Run (NumPy and SciPy):

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python projection_checks.py
```

The program writes projection_results.json. Preserve the supplied result as a
reference or copy the directory before rerunning. `run_output.txt` is the recorded
stdout of the supplied final source. `RUN_METADATA.json` and `SHA256.json` identify
the environment and file contents.

42 named positive cases; 5 negative controls. No user repository or production files
were accessed or changed. No moving-body timestep, cut-cell transport or real-time
performance is claimed. This is evidence for a next bounded component specification,
not an authorization for an agent to implement/integrate new stages.
